package main;

import java.awt.Point;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;

import drawing.Drawing;
import drawing.Stroke;

public class Card {
	public char kanji;
	public String meaning;
	public Drawing writing;
	public final int index;
	private double inaccuracyRate = 1;

	public static double totalInaccuracy, inaccuracyAdjustment = 6;
	public static Card[] allCards;
	public static Drawing[] ds;

	public Card(char kanji, String meaning, int index) {
		this.kanji = kanji;
		this.meaning = meaning;
		this.index = index;
	}

	public static Card random(Card c) {
		ArrayList<Card> list = new ArrayList<>(Arrays.asList(allCards));
		list.sort((a, b) -> (int) Math.signum(b.inaccuracyRate - a.inaccuracyRate));
		double r = Math.random() * totalInaccuracy;
		for (int i = 0; i < list.size(); i++)
			if ((r -= list.get(i).inaccuracyRate) <= 0)
				return c != null && list.get(i).equals(c) ? list.get((i + 1) % list.size()) : list.get(i);
		throw new Error("something went really wrong. :\\ (r = " + r + ", cards: " + allCards.length + ")");
	}

	public void adjustInaccuracyRate(boolean isAnswerCorrect) {
		double prev = inaccuracyRate;
		if (isAnswerCorrect) {
			inaccuracyRate /= inaccuracyAdjustment;
		} else {
			inaccuracyRate *= inaccuracyAdjustment;
		}
		totalInaccuracy += inaccuracyRate - prev;
	}

	public static Drawing[] loadWriting() {
		try {
			InputStream stream;
			if (Main.loadFromJar)
				stream = Main.class.getResourceAsStream("/assets/writings");
			else
				stream = new FileInputStream(new File("assets/writings"));
			ByteArrayOutputStream byteArray = new ByteArrayOutputStream();
			byte[] buffer = new byte[4096];
			int av;
			while ((av = stream.read(buffer, 0, buffer.length)) != -1)
				byteArray.write(buffer, 0, av);
			stream.close();
			ByteArrayInputStream in = new ByteArrayInputStream(byteArray.toByteArray());
			Drawing[] ds = new Drawing[in.read() << 8 | in.read()];
			for (int i = 0; i < ds.length; i++) {
				ds[i] = new Drawing();
				in.skip(2);
				int strokes = in.read() << 8 | in.read();
				for (int j = 0; j < strokes; j++) {
					ds[i].add(new Stroke());
					int points = in.read() << 8 | in.read();
					for (int k = 0; k < points; k++)
						ds[i].last().add(new Point(in.read() << 8 | in.read(), in.read() << 8 | in.read()));
					if (j != 0)
						ds[i].strokes[j - 1].addNext(ds[i].last());
					ds[i].last().finish();
				}
				ds[i].finish();
			}
			return ds;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public static void start(int[] groups) {
		try {
			while (ds == null)
				Thread.sleep(20);
		} catch (Exception e) {
		}
		String data;
		try {
			InputStream stream;
			if (Main.loadFromJar)
				stream = Main.class.getResourceAsStream("/assets/kanji.txt");
			else
				stream = new FileInputStream(new File("assets/kanji.txt"));
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			byte[] buffer = new byte[1024];
			int read;
			while ((read = stream.read(buffer)) != -1)
				out.write(buffer, 0, read);
			stream.close();
			data = new String(out.toByteArray(), "UTF8");
		} catch (Exception e) {
			e.printStackTrace();
			while (true)
				System.exit(0);
		}
		if (data.charAt(0) == '\uFEFF')
			data = data.substring(1);
		String[] lines = data.split(System.getProperty("line.separator"));
		Card[] cards = new Card[lines.length];
		int cardsSize = 0, group = 0;
		boolean readCurrentGroup = false;
		for (int i = 0; i < lines.length; i++)
			if (!lines[i].contains("\t")) {
				group++;
				readCurrentGroup = false;
				for (int j : groups)
					if (j == group) {
						readCurrentGroup = true;
						break;
					}
			} else if (readCurrentGroup) {
				String kanji = lines[i].substring(0, lines[i].indexOf('\t'));
				if (kanji.length() >= 1) {
					cards[cardsSize++] = new Card(kanji.charAt(0), lines[i].substring(kanji.length() + 1),
							cardsSize - 1);
					cards[cardsSize - 1].writing = ds[i - group];
					if (kanji.length() > 1)
						System.out.println("Warning: unused symbol(s) after kanji on line " + (i + 1));
				} else
					System.out.println("Warning: no kanji before tab on line " + (i + 1) + "; skipping line");
			}
		allCards = new Card[cardsSize];
		totalInaccuracy = cardsSize;
		for (int i = 0; i < cardsSize; i++)
			allCards[i] = cards[i];
	}

	public boolean equals(Card c) {
		return index == c.index;
	}

	public boolean equals(Object o) {
		return o == null ? false : (o instanceof Card ? (equals((Card) o)) : false);
	}
}
