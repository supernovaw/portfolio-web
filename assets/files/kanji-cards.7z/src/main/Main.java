package main;

import java.awt.Dimension;

import javax.swing.UIManager;

import gui.StartGUI;

public class Main {
	public static final boolean loadFromJar = false;

	public static Dimension windowSize = new Dimension(1366, 768);

	public static void main(String[] args) {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
			System.out.println("Warning: error while setting system LookAndFeel (" + e.getMessage() + ")");
		}
		Theme.load();
		new StartGUI();
		Card.ds = Card.loadWriting();
	}
}
