package main;

import java.awt.Color;
import java.awt.Font;
import java.io.File;

public class Theme {
	public static String title = "教育漢字";
	public static Font font, jpfont;
	public static Color bg = Color.white, fg = Color.black;

	public static void load() {
		try {
			if (Main.loadFromJar) {
				font = Font.createFont(Font.TRUETYPE_FONT,
						Main.class.getResourceAsStream("/assets/SFUIText-Light.ttf"));
				jpfont = Font.createFont(0, Main.class.getResourceAsStream("/assets/UDDigiKyokashoN-R.ttc"));
			} else {
				font = Font.createFont(Font.TRUETYPE_FONT, new File("assets/SFUIText-Light.ttf"));
				jpfont = Font.createFont(0, new File("assets/UDDigiKyokashoN-R.ttc"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static Color colorBetween(double d) { // from bg to fg as d goes from 0 to 1
		return new Color((int) (bg.getRed() * d + fg.getRed() * (1 - d)),
				(int) (bg.getGreen() * d + fg.getGreen() * (1 - d)), (int) (bg.getBlue() * d + fg.getBlue() * (1 - d)));
	}
}
