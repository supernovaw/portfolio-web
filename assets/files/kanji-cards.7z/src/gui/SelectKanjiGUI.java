package gui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JLabel;

import main.Card;
import main.Main;
import main.Theme;

public class SelectKanjiGUI extends JFrame {
	public static int variantsNumber = 6, variantsOffset = 50;
	public static Font meaningF = Theme.font.deriveFont(0, 50), answerF = Theme.jpfont.deriveFont(0, 100),
			variantF = Theme.jpfont.deriveFont(0, 90);
	public static Rectangle meaningR = new Rectangle(-400, -100, 800, 80), answerR = new Rectangle(-60, 200, 120, 120),
			variantR = new Rectangle(-50, 0, 100, 100);

	public JLabel meaning, answer, variants[], score;
	public Card current;
	public int scoreCorrect, scoreMistakes;

	public SelectKanjiGUI() {
		current = Card.random(null);
		getContentPane().setPreferredSize(Main.windowSize);
		pack();
		setTitle(Theme.title);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(3);
		setLayout(null);
		getContentPane().setBackground(Theme.bg);
		int hw = main.Main.windowSize.width / 2, hh = main.Main.windowSize.height / 2;
		meaning = new JLabel();
		meaning.setBounds(hw + meaningR.x, hh + meaningR.y, meaningR.width, meaningR.height);
		meaning.setText(current.meaning);
		meaning.setForeground(Theme.fg);
		meaning.setHorizontalAlignment(0);
		meaning.setFont(meaningF);
		add(meaning);
		variants = new JLabel[variantsNumber];
		int startOffset = -(variantsNumber - 1) * (variantR.width + variantsOffset) / 2;
		MouseAdapter m = new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				char kanji = ((JLabel) e.getSource()).getText().charAt(0);
				boolean correct = kanji == current.kanji;
				if (correct) {
					answer.setText(null);
					scoreCorrect++;
				} else {
					answer.setText(Character.toString(current.kanji));
					scoreMistakes++;
				}
				current.adjustInaccuracyRate(correct);
				current = Card.random(current);
				meaning.setText(current.meaning);
				setRandomKanji();
				score.setText(scoreCorrect + ":" + scoreMistakes);
			}
		};
		for (int i = 0; i < variantsNumber; i++) {
			JLabel variant = new JLabel();
			variant.setBounds(startOffset + hw + variantR.x + i * (variantsOffset + variantR.width), hh + variantR.y,
					variantR.width, variantR.height);
			variant.setForeground(Theme.fg);
			variant.setHorizontalAlignment(0);
			variant.setFont(variantF);
			variant.addMouseListener(m);
			add(variant);
			variants[i] = variant;
		}
		setRandomKanji();
		answer = new JLabel();
		answer.setBounds(hw + answerR.x, hh + answerR.y, answerR.width, answerR.height);
		answer.setForeground(Theme.fg);
		answer.setHorizontalAlignment(0);
		answer.setFont(answerF);
		add(answer);
		score = new JLabel();
		score.setText("0:0");
		score.setBounds(10, getContentPane().getHeight() - 40, 100, 30);
		score.setFont(new Font("SF UI Text", 0, 25));
		score.setBackground(Color.black);
		score.setForeground(Theme.fg);
		add(score);
		getContentPane().addComponentListener(new ComponentAdapter() {
			public void componentResized(ComponentEvent e) {
				onResize();
			}
		});
		setVisible(true);
	}

	public void setRandomKanji() {
		int correct = (int) (Math.random() * variantsNumber);
		ArrayList<Card> used = new ArrayList<>();
		used.add(current);
		for (int i = 0; i < variantsNumber; i++) {
			if (i == correct)
				continue;
			Card c = Card.random(current);
			while (used.contains(c))
				c = Card.random(current);
			used.add(c);
			variants[i].setText(Character.toString(c.kanji));
		}
		variants[correct].setText(Character.toString(current.kanji));
	}

	public void onResize() {
		double scale = getContentPane().getHeight() / Main.windowSize.getHeight();
		int hw = getContentPane().getWidth() / 2, hh = getContentPane().getHeight() / 2;
		meaning.setBounds(hw + (int) (scale * meaningR.x), hh + (int) (scale * meaningR.y),
				(int) (scale * meaningR.width), (int) (scale * meaningR.height));
		meaning.setFont(meaningF.deriveFont((int) (meaningF.getSize() * scale / 2) * 2f));
		int startOffset = -(variantsNumber - 1) * (int) (scale * (variantR.width + variantsOffset)) / 2;
		for (int i = 0; i < variantsNumber; i++) {
			variants[i].setBounds(
					startOffset + hw + (int) (scale * variantR.x)
							+ i * (int) (scale * (variantsOffset + variantR.width)),
					hh + (int) (scale * variantR.y), (int) (scale * variantR.width), (int) (scale * variantR.height));
			variants[i].setFont(variantF.deriveFont((int) (variantF.getSize() * scale / 2) * 2f));
		}
		answer.setBounds(hw + (int) (scale * answerR.x), hh + (int) (scale * answerR.y), (int) (scale * answerR.width),
				(int) (scale * answerR.height));
		answer.setFont(answerF.deriveFont((int) (answerF.getSize() * scale / 2) * 2f));
		score.setBounds(10, getContentPane().getHeight() - 40, 100, 30);
	}
}
