package gui;

import java.awt.Font;
import java.awt.Rectangle;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import main.Card;
import main.Main;
import main.Theme;

public class DrawKanjiGUI extends JFrame {
	public static Font meaningF = Theme.font.deriveFont(0, 50), goF = Theme.font.deriveFont(0, 20),
			answerF = Theme.jpfont.deriveFont(0, 180);
	public static Rectangle meaningR = new Rectangle(-400, -370, 800, 80), kanjiR = new Rectangle(-200, -290, 400, 400),
			goR = new Rectangle(-200, 120, 400, 40), answerR = new Rectangle(-100, 170, 200, 200);

	public JLabel meaning, answer, score;
	public KanjiDrawArea kanji;
	public JButton go;
	public Card current;
	public int scoreCorrect, scoreMistakes;

	public DrawKanjiGUI() {
		current = Card.random(null);
		getContentPane().setPreferredSize(Main.windowSize);
		pack();
		setTitle(Theme.title);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(3);
		setLayout(null);
		getContentPane().setBackground(Theme.bg);
		int hw = main.Main.windowSize.width / 2, hh = main.Main.windowSize.height / 2;
		meaning = new JLabel();
		meaning.setBounds(hw + meaningR.x, hh + meaningR.y, meaningR.width, meaningR.height);
		meaning.setText(current.meaning);
		meaning.setForeground(Theme.fg);
		meaning.setHorizontalAlignment(0);
		meaning.setFont(meaningF);
		add(meaning);
		kanji = new KanjiDrawArea();
		kanji.setBounds(hw + kanjiR.x, hh + kanjiR.y, kanjiR.width, kanjiR.height);
		kanji.setBackground(Theme.colorBetween(.98));
		kanji.setForeground(Theme.fg);
		add(kanji);
		go = new JButton("Go");
		go.addActionListener(e -> {
			Card guess = kanji.clear().getMostSimilar();
			boolean correct = guess == null ? false : current.kanji == guess.kanji;
			if (correct) {
				answer.setText(null);
				scoreCorrect++;
			} else {
				answer.setText(Character.toString(current.kanji));
				scoreMistakes++;
			}
			score.setText(scoreCorrect + ":" + scoreMistakes);
			current.adjustInaccuracyRate(correct);
			current = Card.random(current);
			meaning.setText(current.meaning);
		});
		go.setBounds(hw + goR.x, hh + goR.y, goR.width, goR.height);
		go.setForeground(Theme.fg);
		go.setFocusPainted(false);
		go.setFont(goF);
		add(go);
		answer = new JLabel();
		answer.setBounds(hw + answerR.x, hh + answerR.y, answerR.width, answerR.height);
		answer.setFont(answerF);
		answer.setForeground(Theme.fg);
		answer.setBackground(Theme.bg);
		add(answer);
		score = new JLabel();
		score.setText("0:0");
		score.setBounds(10, getContentPane().getHeight() - 40, 100, 30);
		score.setFont(new Font("SF UI Text", 0, 25));
		score.setBackground(Theme.bg);
		score.setForeground(Theme.fg);
		add(score);
		addComponentListener(new ComponentAdapter() {
			public void componentResized(ComponentEvent e) {
				onResize();
			}
		});
		setVisible(true);
	}

	public void onResize() {
		double scale = getContentPane().getHeight() / Main.windowSize.getHeight();
		int hw = getContentPane().getWidth() / 2, hh = getContentPane().getHeight() / 2;
		meaning.setBounds(hw + (int) (scale * meaningR.x), hh + (int) (scale * meaningR.y),
				(int) (scale * meaningR.width), (int) (scale * meaningR.height));
		meaning.setFont(meaningF.deriveFont((int) (meaningF.getSize() * scale / 2) * 2f));
		kanji.setBounds(hw + (int) (scale * kanjiR.x), hh + (int) (scale * kanjiR.y), (int) (scale * kanjiR.width),
				(int) (scale * kanjiR.height));
		go.setBounds(hw + (int) (scale * goR.x), hh + (int) (scale * goR.y), (int) (scale * goR.width),
				(int) (scale * goR.height));
		go.setFont(goF.deriveFont((int) (goF.getSize() * scale / 2) * 2f));
		answer.setBounds(hw + (int) (scale * answerR.x), hh + (int) (scale * answerR.y), (int) (scale * answerR.width),
				(int) (scale * answerR.height));
		answer.setFont(answerF.deriveFont((int) (answerF.getSize() * scale / 2) * 2f));
		score.setBounds(10, getContentPane().getHeight() - 40, 100, 30);
	}
}
