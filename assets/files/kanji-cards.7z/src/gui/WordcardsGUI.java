package gui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import main.Card;
import main.Main;
import main.Theme;

public class WordcardsGUI extends JFrame {
	public static Rectangle kanjiR = new Rectangle(-150, -300, 300, 300), fieldR = new Rectangle(-200, 100, 400, 80),
			answerR = new Rectangle(-400, 200, 800, 80);
	public static Font kanjiF = Theme.jpfont.deriveFont(0, 270), fieldF = Theme.font.deriveFont(0, 50),
			answerF = new Font("SF UI Text", 0, 50);

	public JLabel kanji, answer, score;
	public JTextField field;
	public Card current;
	public int scoreCorrect, scoreMistakes;

	public WordcardsGUI() {
		current = Card.random(null);
		getContentPane().setPreferredSize(Main.windowSize);
		pack();
		setTitle(Theme.title);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(3);
		setLayout(null);
		getContentPane().setBackground(Theme.bg);
		int hw = main.Main.windowSize.width / 2, hh = main.Main.windowSize.height / 2;
		kanji = new JLabel();
		kanji.setBounds(hw + kanjiR.x, hh + kanjiR.y, kanjiR.width, kanjiR.height);
		kanji.setText(Character.toString(current.kanji));
		kanji.setBorder(BorderFactory.createEmptyBorder());
		kanji.setForeground(Theme.fg);
		kanji.setHorizontalAlignment(0);
		kanji.setFont(kanjiF);
		add(kanji);
		field = new JTextField();
		field.setBounds(hw + fieldR.x, hh + fieldR.y, fieldR.width, fieldR.height);
		field.setForeground(Theme.fg);
		field.setBackground(Theme.bg);
		field.setCaretColor(Color.lightGray);
		field.setFont(fieldF);
		field.addActionListener(e -> {
			boolean correct = current.meaning.equals(field.getText());
			if (correct) {
				answer.setText(null);
				scoreCorrect++;
			} else {
				answer.setText(current.meaning);
				scoreMistakes++;
			}
			current.adjustInaccuracyRate(correct);
			field.setText(null);
			current = Card.random(current);
			kanji.setText(Character.toString(current.kanji));
			score.setText(scoreCorrect + ":" + scoreMistakes);
		});
		add(field);
		answer = new JLabel();
		answer.setBounds(hw + answerR.x, hh + answerR.y, answerR.width, answerR.height);
		answer.setForeground(Theme.fg);
		answer.setHorizontalAlignment(0);
		answer.setFont(answerF);
		add(answer);
		score = new JLabel();
		score.setText("0:0");
		score.setBounds(10, getContentPane().getHeight() - 40, 100, 30);
		score.setFont(Theme.font.deriveFont(0, 25));
		score.setBackground(Theme.bg);
		score.setForeground(Theme.fg);
		add(score);
		getContentPane().addComponentListener(new ComponentAdapter() {
			public void componentResized(ComponentEvent e) {
				onResize();
			}
		});
		setVisible(true);
	}

	public void onResize() {
		double scale = getContentPane().getHeight() / Main.windowSize.getHeight();
		int hw = getContentPane().getWidth() / 2, hh = getContentPane().getHeight() / 2;
		kanji.setBounds(hw + (int) (scale * kanjiR.x), hh + (int) (scale * kanjiR.y), (int) (scale * kanjiR.width),
				(int) (scale * kanjiR.height));
		kanji.setFont(kanjiF.deriveFont((int) (kanjiF.getSize() * scale / 2) * 2f));
		field.setBounds(hw + (int) (scale * fieldR.x), hh + (int) (scale * fieldR.y), (int) (scale * fieldR.width),
				(int) (scale * fieldR.height));
		field.setFont(fieldF.deriveFont((int) (fieldF.getSize() * scale / 2) * 2f));
		answer.setBounds(hw + (int) (scale * answerR.x), hh + (int) (scale * answerR.y), (int) (scale * answerR.width),
				(int) (scale * answerR.height));
		answer.setFont(answerF.deriveFont((int) (answerF.getSize() * scale / 2) * 2f));
		score.setBounds(10, getContentPane().getHeight() - 40, 100, 30);
	}
}
