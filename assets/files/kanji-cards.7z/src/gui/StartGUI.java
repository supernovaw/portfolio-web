package gui;

import java.awt.Dimension;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;

import main.Card;
import main.Main;
import main.Theme;

public class StartGUI extends JFrame {
	public static String[] kanjiGroups;
	private JCheckBox[] groups;

	public StartGUI() {
		try {
			InputStream stream;
			if (Main.loadFromJar)
				stream = Main.class.getResourceAsStream("/assets/groups.txt");
			else
				stream = new FileInputStream(new File("assets/groups.txt"));
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			byte[] buffer = new byte[1024];
			int read;
			while ((read = stream.read(buffer)) != -1)
				out.write(buffer, 0, read);
			String names = new String(out.toByteArray(), "UTF8");
			names = names.charAt(0) == '\uFEFF' ? names.substring(1) : names;
			kanjiGroups = names.split(System.lineSeparator());
		} catch (Exception e) {
			e.printStackTrace();
		}
		setTitle(Theme.title);
		setDefaultCloseOperation(3);
		setLayout(null);
		getContentPane().setBackground(Theme.bg);
		groups = new JCheckBox[kanjiGroups.length];
		int columnSize = 15, buttonsHeight = 25 + Math.min(columnSize, kanjiGroups.length) * 35,
				width = 40 + 160 * (int) Math.ceil((double) kanjiGroups.length / columnSize);
		for (int i = 0; i < kanjiGroups.length; i++) {
			groups[i] = new JCheckBox(kanjiGroups[i], false);
			groups[i].setBounds(20 + i / columnSize * 160, 20 + i % columnSize * 35, 150, 30);
			groups[i].setForeground(Theme.fg);
			groups[i].setContentAreaFilled(false);
			groups[i].setFocusPainted(false);
			add(groups[i]);
		}
		getContentPane().setPreferredSize(new Dimension(width, columnSize * 35 + 97));
		pack();
		setLocationRelativeTo(null);
		ButtonGroup modes = new ButtonGroup();
		JRadioButton mode1 = new JRadioButton("Вводить значение кандзи", true);
		mode1.setBounds(20, buttonsHeight, 190, 30);
		mode1.setFocusPainted(false);
		mode1.setContentAreaFilled(false);
		mode1.setForeground(Theme.fg);
		modes.add(mode1);
		add(mode1);
		JRadioButton mode2 = new JRadioButton("Выбирать правильный кандзи");
		mode2.setBounds(220, buttonsHeight, 190, 30);
		mode2.setFocusPainted(false);
		mode2.setContentAreaFilled(false);
		mode2.setForeground(Theme.fg);
		modes.add(mode2);
		add(mode2);
		JRadioButton mode3 = new JRadioButton("Рисовать кандзи");
		mode3.setBounds(20, 30 + buttonsHeight, 190, 30);
		mode3.setFocusPainted(false);
		mode3.setContentAreaFilled(false);
		mode3.setForeground(Theme.fg);
		modes.add(mode3);
		add(mode3);
		JButton button = new JButton("Go!");
		button.addActionListener(e -> {
			int[] groups = getGroups();
			if (groups.length == 0)
				JOptionPane.showMessageDialog(null, "Нужно выбрать хотя бы 1 группу кандзи");
			else {
				setVisible(false);
				if (mode1.isSelected()) {
					Card.start(groups);
					new WordcardsGUI();
				} else if (mode2.isSelected()) {
					Card.start(groups);
					new SelectKanjiGUI();
				} else {
					Card.start(groups);
					new DrawKanjiGUI();
				}
			}
		});
		button.setBounds(width - 75, 23 + buttonsHeight, 70, 24);
		button.setForeground(Theme.fg);
		button.setBorder(BorderFactory.createLineBorder(Theme.fg));
		button.setContentAreaFilled(false);
		add(button);
		setVisible(true);
		setResizable(false);
	}

	private int[] getGroups() {
		int values[] = new int[groups.length], valuesSize = 0;
		for (int i = 0; i < groups.length; i++)
			if (groups[i].isSelected())
				values[valuesSize++] = i + 1;
		int[] result = new int[valuesSize];
		for (int i = 0; i < valuesSize; i++)
			result[i] = values[i];
		return result;
	}
}
