package gui;

import java.awt.BasicStroke;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import drawing.Drawing;
import drawing.Stroke;

public class KanjiDrawArea extends JPanel {
	private Drawing drawing;
	private boolean currentlyDrawing;

	public KanjiDrawArea() {
		drawing = new Drawing();
		MouseAdapter m = new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				if (e.getButton() == 1) {
					currentlyDrawing = true;
					drawing.add(new Stroke());
				} else if (e.getButton() == 3) {
					if (!currentlyDrawing) {
						drawing.used = Math.max(0, drawing.used - 1);
						repaint();
					}
				}
			}

			public void mouseDragged(MouseEvent e) {
				if (SwingUtilities.isLeftMouseButton(e)) {
					drawing.last().add(e.getPoint());
					repaint();
				}
			}

			public void mouseReleased(MouseEvent e) {
				if (e.getButton() == 1) {
					currentlyDrawing = false;
					if (drawing.last().used < Stroke.regularStep + 1)
						drawing.used--;
					else {
						drawing.last().finish();
						if (drawing.used > 1)
							drawing.strokes[drawing.used - 2].addNext(drawing.last());
					}
				}
			}
		};
		addMouseListener(m);
		addMouseMotionListener(m);
	}

	public Drawing clear() {
		drawing.finish();
		Drawing d = drawing;
		drawing = new Drawing();
		repaint();
		return d;
	}

	protected void paintComponent(Graphics g) {
		g.setColor(getBackground());
		g.fillRect(0, 0, getWidth(), getHeight());
		g.setColor(getForeground());
		((Graphics2D) g).setStroke(new BasicStroke(7, BasicStroke.CAP_ROUND, BasicStroke.JOIN_BEVEL, 0f));

		((Graphics2D) g).setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		for (int i = 0; i < drawing.used; i++)
			for (int j = 0, s = 1; j < drawing.strokes[i].used - s; j++) {
				g.drawLine(drawing.strokes[i].path[j].x, drawing.strokes[i].path[j].y, drawing.strokes[i].path[j + s].x,
						drawing.strokes[i].path[j + s].y);
			}
	}
}
