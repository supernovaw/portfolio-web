package strokes;

import drawing.Stroke;
import java.awt.Point;

public class Brushstroke {
	public Stroke path;
	public int sel;

	public Brushstroke(Stroke path) {
		this.path = path;
	}

	public Point getSel1() {
		return this.path.path[0];
	}

	public Point getSel2() {
		return this.path.path[(this.path.used - 1)];
	}
}
