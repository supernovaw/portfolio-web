package strokes;

import java.awt.Point;
import java.util.ArrayList;

import main.Card;

public class Kanji {
	public Brushstroke[] strokes;
	public ArrayList<Point> selected;
	public Point[] points;

	public Kanji(Card c) {
		this.strokes = new Brushstroke[c.writing.used];
		for (int i = 0; i < c.writing.used; i++) {
			this.strokes[i] = new Brushstroke(c.writing.strokes[i]);
		}
		this.points = new Point[c.writing.used * 2];
		for (int i = 0; i < c.writing.used; i++) {
			this.points[(i * 2)] = this.strokes[i].getSel1();
			this.points[(i * 2 + 1)] = this.strokes[i].getSel2();
		}
		this.selected = new ArrayList<>();
	}

	public int indexOf(Point p) {
		for (int i = 0; i < this.points.length; i++) {
			if (this.points[i].equals(p)) {
				return i;
			}
		}
		return -1;
	}

	public Point nearest(Point p) {
		double[] dist = new double[this.points.length];
		for (int i = 0; i < dist.length; i++) {
			dist[i] = Math.hypot(p.x - this.points[i].x, p.y - this.points[i].y);
		}
		int j = 0;
		for (int i = 0; i < dist.length; i++) {
			if (dist[i] > dist[j]) {
				j = i;
			}
		}
		return this.points[j];
	}
}
