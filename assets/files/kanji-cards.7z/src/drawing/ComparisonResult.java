package drawing;

class ComparisonResult {
	public double c;
	public int index;

	public ComparisonResult(double c, int index) {
		this.c = c;
		this.index = index;
	}
}
