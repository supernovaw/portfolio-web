package drawing;
import java.awt.Point;

public class Stroke {
	public static double thresold = .2;
	public static int regularStep = 4;
	public Point[] path;
	public double[] angles;
	public int used;
	public NextTie next;
	private boolean finished;

	public Stroke() {
		path = new Point[4096];
	}

	public void add(Point p) {
		if (finished)
			throw new Error("already finished");
		path[used++] = p;
	}

	public void finish() {
		if (finished)
			throw new Error("already finished");
		finished = true;
		Point[] result = new Point[used];
		for (int i = 0; i < used; i++)
			result[i] = path[i];
		path = result;
		angles = toAngles(regularStep);
	}

	public boolean isFinished() {
		return finished;
	}

	public double[] toAngles(int step) {
		double[] result = new double[path.length - step];
		for (int i = 0; i < result.length; i++)
			result[i] = Math.atan2(path[i + step].y - path[i].y, path[i + step].x - path[i].x);
		return result;
	}

	public void addNext(Stroke next) {
		this.next = new NextTie(this, next);
	}

	public static double compare(double[] s1, double[] s2) {
		double difference = 0;
		for (int i = 0; i < s2.length; i++) {
			double index = (double) i * s1.length / s2.length;
			double v1 = s1[(int) index], v2 = s1[Math.min((int) Math.ceil(index), s1.length - 1)];
			double v = v1 + (v2 - v1) * (index % 1);
			double min = Math.min(Math.min(Math.abs(v - s2[i]), Math.abs(v - s2[i] + Math.PI * 2)),
					Math.abs(v - s2[i] - Math.PI * 2));
			difference += Math.max(0, min - thresold);
		}
		difference /= s2.length;
		return difference;
	}
}
