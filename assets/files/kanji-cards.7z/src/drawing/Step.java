package drawing;

public class Step {
	public XY[] step;

	public Step(XY[] step) {
		this.step = step;
	}

	public XY mid() {
		return step[step.length / 2];
	}
}
