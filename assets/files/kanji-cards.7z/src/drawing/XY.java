package drawing;

public class XY {
	public int x, y;

	public XY(int x, int y) {
		this.x = x;
		this.y = y;
	}

	public boolean equals(Object obj) {
		return obj instanceof XY ? (((XY) obj).x == x && ((XY) obj).y == y) : false;
	}
}
