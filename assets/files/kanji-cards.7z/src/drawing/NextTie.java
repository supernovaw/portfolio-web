package drawing;
import java.awt.Point;
import java.io.Serializable;

public class NextTie implements Serializable {
	public static double thresold = .5;
	public double from1to1X, from1to1Y, from1to2X, from1to2Y, from2to1X, from2to1Y, from2to2X, from2to2Y;

	public NextTie(Stroke s1, Stroke s2) {
		Point p1_1 = s1.path[0], p1_2 = s1.path[s1.used - 1], p2_1 = s2.path[0], p2_2 = s2.path[s2.used - 1];
		double dist = Math.hypot(p1_1.x - p1_2.x, p1_1.y - p1_2.y);
		from1to1X = (p2_1.x - p1_1.x) / dist;
		from1to1Y = (p2_1.y - p1_1.y) / dist;
		from1to2X = (p2_2.x - p1_1.x) / dist;
		from1to2Y = (p2_2.y - p1_1.y) / dist;
		from2to1X = (p2_1.x - p1_2.x) / dist;
		from2to1Y = (p2_1.y - p1_2.y) / dist;
		from2to2X = (p2_2.x - p1_2.x) / dist;
		from2to2Y = (p2_2.y - p1_2.y) / dist;
	}

	public NextTie(double v1, double v2, double v3, double v4, double v5, double v6, double v7, double v8) {
		from1to1X = v1;
		from1to1Y = v2;
		from1to2X = v3;
		from1to2Y = v4;
		from2to1X = v5;
		from2to1Y = v6;
		from2to2X = v7;
		from2to2Y = v8;
	}

	public double compare(NextTie t) {
		double result = 0;
		result += Math.max(Math.hypot(from1to1X - t.from1to1X, from1to1Y - t.from1to1Y) - thresold, 0);
		result += Math.max(Math.hypot(from1to2X - t.from1to2X, from1to2Y - t.from1to2Y) - thresold, 0);
		result += Math.max(Math.hypot(from2to1X - t.from2to1X, from2to1Y - t.from2to1Y) - thresold, 0);
		result += Math.max(Math.hypot(from2to2X - t.from2to2X, from2to2Y - t.from2to2Y) - thresold, 0);
		return result;
	}
}
