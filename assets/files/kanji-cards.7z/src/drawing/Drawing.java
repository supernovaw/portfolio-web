package drawing;

import java.util.ArrayList;

import main.Card;

public class Drawing {
	public static final double correctWritingThresold = 5; // the less value is, the more accurate you have to write
	public Stroke[] strokes;
	public int used;
	private boolean finished;

	public Drawing() {
		strokes = new Stroke[256];
	}

	public void add(Stroke s) {
		if (finished)
			throw new Error("already finished");
		strokes[used++] = s;
	}

	public Stroke last() {
		return strokes[used - 1];
	}

	public void finish() {
		if (finished)
			throw new Error("already finished");
		finished = true;
		Stroke[] result = new Stroke[used];
		for (int i = 0; i < used; i++)
			result[i] = strokes[i];
		strokes = result;
	}

	public boolean isFinished() {
		return finished;
	}

	public double compare(Drawing d) {
		if (!d.finished)
			throw new Error("arg should be finished");
		if (d.strokes.length != strokes.length)
			return -1;
		double anglesDifference = 0, positionDifference = 0;
		for (int i = 0; i < strokes.length; i++)
			anglesDifference += Stroke.compare(strokes[i].angles, d.strokes[i].angles);
		for (int i = 0; i < strokes.length - 1; i++)
			positionDifference += strokes[i].next.compare(d.strokes[i].next);
		return anglesDifference / strokes.length
				+ (strokes.length == 1 ? 0 : positionDifference / (strokes.length - 1));
	}

	public Card getMostSimilar() {
		ArrayList<ComparisonResult> results = new ArrayList<>();
		for (int i = 0; i < Card.allCards.length; i++)
			results.add(new ComparisonResult(compare(Card.allCards[i].writing), Card.allCards[i].index));
		results.sort((a, b) -> {
			if (a.c == -1 && b.c == -1)
				return 0;
			if (a.c == -1)
				return 1;
			if (b.c == -1)
				return -1;
			return (int) Math.signum(a.c - b.c);
		});
		if (results.get(0).c == -1 || results.get(0).c > correctWritingThresold)
			return null;
		return Card.allCards[results.get(0).index];
	}
}
