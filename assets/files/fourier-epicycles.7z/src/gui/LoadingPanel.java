package gui;

import java.awt.Color;

import javax.swing.JLabel;
import javax.swing.JPanel;

import main.Main;

public class LoadingPanel extends JPanel {
	public JLabel label;

	public LoadingPanel() {
		label = new JLabel();
		label.setBounds(100, 100, 600, 100);
		label.setForeground(Color.white);
		label.setFont(Main.font.deriveFont(0, 50));
		add(label);

		setBackground(Color.black);
		setForeground(Color.white);
		setLayout(null);
	}
}
