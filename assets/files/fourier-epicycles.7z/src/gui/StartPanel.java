package gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import main.Chain;
import main.Main;

public class StartPanel extends JPanel {
	public JLabel pathLabel, epicyclesLabel;
	public JTextField pathField, epicyclesField;
	public JRadioButton loadAdhdButton, parseDrawingButton, pickDotsButton, pickPathButton;
	public ButtonGroup group;
	public JCheckBox saveAdhdCheckbox;
	public JButton goButton;

	public int epicycles;

	public StartPanel() {
		pathLabel = new JLabel("Path");
		epicyclesLabel = new JLabel("Epicycles");
		pathField = new JTextField();
		pathField.setCaretColor(Color.white);
		epicyclesField = new JTextField();
		epicyclesField.setCaretColor(Color.white);
		loadAdhdButton = new JRadioButton("Load .adhd");
		loadAdhdButton.setFocusPainted(false);
		parseDrawingButton = new JRadioButton("Parse drawing");
		parseDrawingButton.setFocusPainted(false);
		pickDotsButton = new JRadioButton("Pick dots");
		pickDotsButton.setFocusPainted(false);
		pickPathButton = new JRadioButton("Pick path");
		pickPathButton.setFocusPainted(false);
		group = new ButtonGroup();
		group.add(loadAdhdButton);
		group.add(parseDrawingButton);
		group.add(pickDotsButton);
		group.add(pickPathButton);
		saveAdhdCheckbox = new JCheckBox("Save .adhd");
		goButton = new JButton("Go");
		goButton.setContentAreaFilled(false);
		goButton.setBorder(BorderFactory.createLineBorder(Color.white));
		goButton.addActionListener(e -> {
			if (loadAdhdButton.isSelected()) {
				try {
					epicycles = Integer.parseInt(epicyclesField.getText());
				} catch (Exception e2) {
					epicycles = 0;
				}
				if (epicycles < 0) {
					JOptionPane.showMessageDialog(null, "Epicycles amount can't be negative (SENSATIONAL!)");
					epicycles = 0;
				}
				File file = getFile();
				if (file.isFile()) {
					new Thread(() -> {
						Chain tsein;
						try {
							tsein = Chain.read(file);
							Main.animationPanel.setChain(tsein, epicycles);
							Main.setPanel(Main.animationPanel);
							Main.animationPanel.start();
							Main.repaintCaller.start();
						} catch (IOException e2) {
							JOptionPane.showMessageDialog(null, e2.getMessage());
						}
					}).start();
				} else
					JOptionPane.showMessageDialog(null, "File " + file.getAbsolutePath() + " doesn't exist");
			} else if (parseDrawingButton.isSelected()) {
				if (pathField.getText().isEmpty())
					JOptionPane.showMessageDialog(null, "Type image filename");
				else {
					try {
						epicycles = Integer.parseInt(epicyclesField.getText());
						if (epicycles < 0)
							JOptionPane.showMessageDialog(null, "Epicycles amount can't be negative (SENSATIONAL!)");
						else {
							loadImage();
							if (Main.image == null)
								JOptionPane.showMessageDialog(null, "Type outlines image filename");
							else {
								Main.setPanel(Main.loadingPanel);
								new Thread(() -> {
									Main.animationPanel.setChain(Chain.createFromOutlines(epicycles));
									Main.setPanel(Main.animationPanel);
									Main.animationPanel.start();
									Main.repaintCaller.start();

								}).start();
							}
						}
					} catch (NumberFormatException e2) {
						JOptionPane.showMessageDialog(null, "Type epicycles amount");
					}
				}
			} else if (pickDotsButton.isSelected()) {
				if (saveAdhdCheckbox.isSelected() && pathField.getText().isEmpty())
					JOptionPane.showMessageDialog(null, "Type filename to save");
				else {
					loadImage();
					Main.setPanel(Main.dotsPickerPanel);
				}
			} else if (pickPathButton.isSelected()) {
				if (saveAdhdCheckbox.isSelected() && pathField.getText().isEmpty())
					JOptionPane.showMessageDialog(null, "Type filename to save");
				else
					try {
						epicycles = Integer.parseInt(epicyclesField.getText());
						if (epicycles < 0)
							JOptionPane.showMessageDialog(null, "Epicycles amount can't be negative (SENSATIONAL!)");
						loadImage();
						Main.setPanel(Main.drawingPanel);
					} catch (NumberFormatException e2) {
						JOptionPane.showMessageDialog(null, "Type epicycles amount");
					}
			}
		});

		setBackground(Color.black);
		setForeground(Color.white);
		setLayout(null);
		addComponentListener(new ComponentAdapter() {
			public void componentResized(ComponentEvent e) {
				int x = getWidth() / 2 - 110, y = getHeight() / 2 - 98;
				pathLabel.setBounds(x, y, 50, 25);
				epicyclesLabel.setBounds(x, y + 35, 50, 25);
				pathField.setBounds(x + 70, y, 150, 25);
				epicyclesField.setBounds(x + 70, y + 35, 150, 25);
				loadAdhdButton.setBounds(x, y + 70, 150, 25);
				parseDrawingButton.setBounds(x, y + 95, 150, 25);
				pickDotsButton.setBounds(x, y + 120, 150, 25);
				pickPathButton.setBounds(x, y + 145, 150, 25);
				saveAdhdCheckbox.setBounds(x, y + 170, 80, 25);
				goButton.setBounds(x + 160, y + 170, 60, 25);
			}
		});
		add(pathLabel);
		add(epicyclesLabel);
		add(pathField);
		add(epicyclesField);
		add(loadAdhdButton);
		add(parseDrawingButton);
		add(pickDotsButton);
		add(pickPathButton);
		add(saveAdhdCheckbox);
		add(goButton);
		for (Component c : getComponents()) {
			c.setBackground(getBackground());
			c.setForeground(getForeground());
		}
	}

	public File getFile() {
		return new File("C:/Users/" + System.getProperty("user.name") + "/Desktop/" + pathField.getText());
	}

	public void loadImage() {
		if (!pathField.getText().isEmpty()) {
			File file = getFile();
			if (file.isFile())
				try {
					if ((Main.image = ImageIO.read(file)) == null)
						JOptionPane.showMessageDialog(null, "Image " + file.getAbsolutePath() + " can't be read");
					else
						Main.picScale = 0;
				} catch (IOException e1) {
					JOptionPane.showMessageDialog(null, "Image " + file.getAbsolutePath() + " can't be read");
				}
			else {
				if (!saveAdhdCheckbox.isSelected() || parseDrawingButton.isSelected())
					JOptionPane.showMessageDialog(null, "File " + file.getAbsolutePath() + " doesn't exist");
			}
		}
	}
}
