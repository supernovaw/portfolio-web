package gui;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.util.ArrayList;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import main.Chain;
import main.Complex;
import main.Main;

public class DrawingPanel extends JPanel {
	public ArrayList<Complex> drawing;

	public DrawingPanel() {
		drawing = new ArrayList<>();
		MouseAdapter mouseAdapter = new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				if (e.getButton() == 1) {
					if (new Rectangle(getWidth() - 85, getHeight() - 40, 70, 25).contains(e.getPoint())) {
						if (drawing.size() < 2)
							JOptionPane.showMessageDialog(null, "There are too few points");
						else {
							Main.setPanel(Main.loadingPanel);
							new Thread(() -> {
								Main.animationPanel.setChain(Chain.createFromPath(
										drawing.toArray(new Complex[drawing.size()]), Main.startPanel.epicycles));
								Main.setPanel(Main.animationPanel);
								Main.animationPanel.start();
								Main.repaintCaller.start();
							}).start();
						}
					} else
						addPoint(e.getPoint());
				} else if (e.getButton() == 3)
					removePoint();
			}

			public void mouseDragged(MouseEvent e) {
				if (SwingUtilities.isLeftMouseButton(e))
					addPoint(e.getPoint());
				else if (SwingUtilities.isRightMouseButton(e))
					removePoint();
			}

			public void mouseWheelMoved(MouseWheelEvent e) {
				Main.picScale += e.getWheelRotation();
				repaint();
			}
		};
		addMouseListener(mouseAdapter);
		addMouseMotionListener(mouseAdapter);
		addMouseWheelListener(mouseAdapter);
	}

	public void addPoint(Point p) {
		drawing.add(new Complex(p, getSize()));
		repaint();
	}

	public void removePoint() {
		if (!drawing.isEmpty()) {
			drawing.remove(drawing.size() - 1);
			repaint();
		}
	}

	protected void paintComponent(Graphics g) {
		Graphics2D g2d = (Graphics2D) g;
		g2d.setColor(Color.black);
		g2d.fillRect(0, 0, getWidth(), getHeight());
		g2d.setColor(Color.white);
		if (Main.image != null) {
			g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, .4f));
			AffineTransform at = new AffineTransform();
			double scale = Math.exp(Main.picScale * -.05d);
			at.translate(getWidth() / 2 - Main.image.getWidth() * scale / 2,
					getHeight() / 2 - Main.image.getHeight() * scale / 2);
			at.scale(scale, scale);
			g2d.drawImage(Main.image, at, null);
			g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1));
		}
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		if (!drawing.isEmpty()) {
			Point2D p = drawing.get(0).getPoint(getSize());
			for (int i = 1; i < drawing.size(); i++) {
				Point2D p2 = drawing.get(i).getPoint(getSize());
				g2d.draw(new Line2D.Double(p.getX(), p.getY(), p2.getX(), p2.getY()));
				p = p2;
			}
		}
		g2d.setFont(Main.font);
		g2d.drawRect(getWidth() - 85, getHeight() - 40, 70, 25);
		g2d.drawString("Go", getWidth() - 85 + 70 / 2 - g2d.getFontMetrics().stringWidth("Go") / 2,
				getHeight() - 40 + 25 / 2 + g2d.getFontMetrics().getAscent() / 2);
	}
}
