package gui;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;

import javax.swing.JPanel;

import main.Chain;
import main.Complex;
import main.Main;
import main.Trail;

public class AnimationPanel extends JPanel {
	public static int timeLimit = 604800; // 60*60*24*7 = 1 week
	public static double expBase = 1.35;

	public Chain chain;
	public Trail trail;

	public double dotsRadius = 2.5;
	public int epicycles, epicyclesMax, cycleTime = 10;
	public boolean showDots = true, showLines = true, showCircles = true;
	public int trailMode = 1;
	public long start;

	public boolean showSettings;
	public static Rectangle settingsR = new Rectangle(10, 10, 80, 20), epicyclesLabelR = new Rectangle(10, 50, 180, 20),
			epicyclesBtn1R = new Rectangle(200, 50, 20, 20), epicyclesBtn2R = new Rectangle(230, 50, 20, 20),
			epicyclesBtn3R = new Rectangle(260, 50, 20, 20), epicyclesBtn4R = new Rectangle(290, 50, 20, 20),
			cycleTimeLabelR = new Rectangle(10, 80, 180, 20), cycleTimeBtn1R = new Rectangle(200, 80, 20, 20),
			cycleTimeBtn2R = new Rectangle(230, 80, 20, 20), cycleTimeBtn3R = new Rectangle(260, 80, 20, 20),
			cycleTimeBtn4R = new Rectangle(290, 80, 20, 20), showDotsR = new Rectangle(10, 120, 100, 20),
			showLinesR = new Rectangle(10, 150, 100, 20), showCirclesR = new Rectangle(10, 180, 100, 20),
			trailR = new Rectangle(10, 220, 100, 20), changeChainR = new Rectangle(10, 260, 100, 20);

	public AnimationPanel() {
		trail = new Trail();
		addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				Point p = e.getPoint();
				if (settingsR.contains(p))
					showSettings = !showSettings;

				if (epicyclesBtn1R.contains(p))
					changeEpicyclesAmount(Math.max((int) ((epicycles - 1) / expBase), 1));
				if (epicyclesBtn2R.contains(p))
					changeEpicyclesAmount(Math.max(epicycles - 1, 1));
				if (epicyclesBtn3R.contains(p))
					changeEpicyclesAmount(Math.min(epicycles + 1, epicyclesMax));
				if (epicyclesBtn4R.contains(p))
					changeEpicyclesAmount(Math.min((int) ((epicycles + 1) * expBase), epicyclesMax));

				if (cycleTimeBtn1R.contains(p))
					changeCycleTime(Math.max((int) ((cycleTime - 1) / expBase), 1));
				if (cycleTimeBtn2R.contains(p))
					changeCycleTime(Math.max(cycleTime - 1, 1));
				if (cycleTimeBtn3R.contains(p))
					changeCycleTime(Math.min(cycleTime + 1, timeLimit));
				if (cycleTimeBtn4R.contains(p))
					changeCycleTime(Math.min((int) ((cycleTime + 1) * expBase), timeLimit));

				if (showDotsR.contains(p))
					showDots = !showDots;
				if (showLinesR.contains(p))
					showLines = !showLines;
				if (showCirclesR.contains(p))
					showCircles = !showCircles;

				if (trailR.contains(p)) {
					trailMode = (trailMode + 1) % 3;
					if (trailMode == 1)
						trail.refresh(0);
					else if (trailMode == 2)
						trail.refresh(2 * Math.PI);
				}
				if (changeChainR.contains(p)) {
					Main.repaintCaller.stop();
					Main.setPanel(Main.startPanel);
				}
			}
		});
	}

	public void changeEpicyclesAmount(int epicycles) {
		this.epicycles = epicycles;
		trail.changeUsedEpicycles(epicycles, trailMode != 0);
	}

	public void start() {
		start = System.currentTimeMillis();
	}

	public void changeCycleTime(int time) {
		long ct = System.currentTimeMillis();
		start = ct - (ct - start) % (cycleTime * 1000) * time / cycleTime;
		cycleTime = time;
	}

	protected void paintComponent(Graphics g) {
		Graphics2D g2d = (Graphics2D) g;
		g2d.setColor(Color.black);
		g2d.fillRect(0, 0, getWidth(), getHeight());
		double t = (System.currentTimeMillis() - start) / (cycleTime * 1000d) % 1 * 2 * Math.PI;
		if (chain == null)
			return;
		if (trailMode == 1)
			trail.refresh(t);
		g2d.setColor(Color.white);
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		Complex c = chain.pos_coef[0], cNew;
		Point2D origin = c.getPoint(getSize());
		if (showDots)
			g2d.fill(new Ellipse2D.Double(origin.getX() - dotsRadius, origin.getY() - dotsRadius, 2 * dotsRadius,
					2 * dotsRadius));
		int lim = epicycles / 2;
		for (int i = 1; i <= lim; i++) {
			if (i == 50)
				g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
			cNew = c.add(chain.pos_coef[i].times(Complex.exp(i * t)));
			drawEpicycle(c, cNew, chain.pos_abs[i], g2d);
			c = cNew;
			cNew = c.add(chain.neg_coef[i].times(Complex.exp(-i * t)));
			drawEpicycle(c, cNew, chain.neg_abs[i], g2d);
			c = cNew;
		}
		if (epicycles % 2 == 1)
			drawEpicycle(c, c.add(chain.pos_coef[lim + 1].times(Complex.exp((lim + 1) * t))), chain.pos_abs[lim + 1],
					g2d);
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		if (trailMode != 0)
			g2d.drawImage(trail.image, getWidth() / 2 - trail.size.width / 2, getHeight() / 2 - trail.size.height / 2,
					null);

		setFont(Main.font);
		drawString(settingsR, "Settings", g2d);
		if (showSettings)
			drawSettings(g2d);
	}

	public void setChain(Chain c, int epicycles) {
		epicyclesMax = c.r * 2;
		if (epicycles == 0 || epicycles > epicyclesMax)
			epicycles = epicyclesMax;
		chain = c;
		this.epicycles = epicycles;
		trail.setChain(c);
		trail.changeUsedEpicycles(epicycles, false);
	}

	public void setChain(Chain c) {
		setChain(c, c.r * 2);
	}

	public void drawEpicycle(Complex c1, Complex c2, double rad, Graphics2D g2d) {
		Point2D p1 = c1.getPoint(getSize()), p2 = c2.getPoint(getSize());
		if (showLines)
			g2d.draw(new Line2D.Double(p1.getX(), p1.getY(), p2.getX(), p2.getY()));
		if (showCircles)
			g2d.draw(new Ellipse2D.Double(p1.getX() - rad, p1.getY() - rad, rad * 2, rad * 2));
		if (showDots)
			g2d.fill(new Ellipse2D.Double(p2.getX() - dotsRadius, p2.getY() - dotsRadius, 2 * dotsRadius,
					2 * dotsRadius));
	}

	public static void drawString(Rectangle rect, String text, Graphics2D g2d) {
		g2d.drawString(text, rect.x + rect.width / 2 - g2d.getFontMetrics().stringWidth(text) / 2,
				rect.y + rect.height / 2 + g2d.getFontMetrics().getAscent() / 2);
	}

	public void drawSettings(Graphics2D g2d) {
		drawString(epicyclesLabelR, "Epicycles: " + epicycles + "/" + epicyclesMax, g2d);
		drawString(epicyclesBtn1R, "- -", g2d);
		drawString(epicyclesBtn2R, "-", g2d);
		drawString(epicyclesBtn3R, "+", g2d);
		drawString(epicyclesBtn4R, "++", g2d);

		drawString(cycleTimeLabelR, "Cycle time: " + cycleTime, g2d);
		drawString(cycleTimeBtn1R, "- -", g2d);
		drawString(cycleTimeBtn2R, "-", g2d);
		drawString(cycleTimeBtn3R, "+", g2d);
		drawString(cycleTimeBtn4R, "++", g2d);

		drawString(showDotsR, showDots ? "Hide dots" : "Show dots", g2d);
		drawString(showLinesR, showLines ? "Hide lines" : "Show lines", g2d);
		drawString(showCirclesR, showCircles ? "Hide circles" : "Show circles", g2d);

		drawString(trailR, trailMode == 0 ? "Trail: hidden" : trailMode == 1 ? "Trail: partial" : "Trail: full", g2d);
		drawString(changeChainR, "Change chain", g2d);
	}
}
