package main;

import java.awt.BasicStroke;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;

public class Trail {
	public static double dt = .0003;

	public BufferedImage image;
	public Dimension size;
	public Graphics2D g2d;
	public Chain chain;
	public int usedEpicycles;
	public double t;
	public Complex last;

	public Trail() {
		size = Toolkit.getDefaultToolkit().getScreenSize();
	}

	public void setChain(Chain c) {
		chain = c;
		usedEpicycles = c.r * 2;
		cleanUp();
	}

	private void cleanUp() {
		image = new BufferedImage(size.width, size.height, 2);
		g2d = (Graphics2D) image.getGraphics();
		g2d.setStroke(new BasicStroke(2f));
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		t = 0;
		last = chain.getPoint(0, usedEpicycles);
	}

	public void changeUsedEpicycles(int epicycles, boolean draw) {
		usedEpicycles = epicycles;
		double t = this.t;
		cleanUp();
		if (draw)
			refresh(t);
	}

	public synchronized void refresh(double tn) {
		if (t - tn > tn)
			cleanUp();
		Point2D l = last.getPoint(size);
		for (; t <= tn; t += dt) {
			Complex c = chain.getPoint(t, usedEpicycles);
			Point2D p = c.getPoint(size);
			g2d.draw(new Line2D.Double(l.getX(), l.getY(), p.getX(), p.getY()));
			last = c;
			l = p;
		}
	}
}
