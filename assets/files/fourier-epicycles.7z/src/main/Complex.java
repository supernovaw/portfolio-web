package main;

import java.awt.Dimension;
import java.awt.Point;
import java.awt.geom.Point2D;

import tsp.XY;

public class Complex {
	public final double re, im;

	public Complex(double re, double im) {
		this.re = re;
		this.im = im;
	}

	public Complex() {
		this(0, 0);
	}

	public Complex(Point point, Dimension size) {
		this(point.getX() - size.getWidth() / 2d, -(point.getY() - size.getHeight() / 2d));
	}

	public Complex(XY xy, int w, int h) {
		this(xy.x - w / 2d, -(xy.y - h / 2d));
	}

	public Complex add(Complex c) {
		return new Complex(re + c.re, im + c.im);
	}

	public Complex subtract(Complex c) {
		return new Complex(re - c.re, im - c.im);
	}

	public double dist(Complex c) {
		return subtract(c).abs();
	}

	public Complex times(Complex c) {
		return new Complex(re * c.re - im * c.im, re * c.im + im * c.re);
	}

	public Complex times(double d) {
		return new Complex(re * d, im * d);
	}

	public Point2D getPoint(Dimension size) {
		return new Point2D.Double(size.getWidth() / 2d + re, size.getHeight() / 2d - im);
	}

	public double abs() {
		return Math.hypot(re, im);
	}

	public static Complex exp(double im) {
		return new Complex(Math.cos(im), Math.sin(im));
	}

	public static Complex between(Complex c1, Complex c2, double fraction) {
		return c1.add(c2.subtract(c1).times(fraction));
	}

	public boolean equals(Complex c) {
		return c.re == re && c.im == im;
	}

	public boolean equals(Object obj) {
		return obj instanceof Complex ? equals((Complex) obj) : false;
	}

	public String toString() {
		return "re: " + re + ", im: " + im;
	}
}
