package main;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;

import tsp.Grid;
import tsp.PathBuilder;
import tsp.XY;

public class Chain {
	public int r;
	public double[] pos_abs, neg_abs;
	public Complex[] pos_coef, neg_coef;

	public Chain(int r) {
		this.r = r;
		pos_abs = new double[r + 1];
		neg_abs = new double[r + 1];
		pos_coef = new Complex[r + 1];
		neg_coef = new Complex[r + 1];
	}

	public Complex getPoint(double t, int epicycles) {
		Complex result = pos_coef[0];
		int lim = epicycles / 2;
		for (int i = 1; i <= lim; i++)
			result = result.add(pos_coef[i].times(Complex.exp(i * t))).add(neg_coef[i].times(Complex.exp(-i * t)));
		if (epicycles % 2 == 1)
			result = result.add(pos_coef[lim + 1].times(Complex.exp((lim + 1) * t)));
		return result;
	}

	public static Chain createFromOutlines(int epicycles) {
		Main.loadingPanel.label.setText("Creating outlines route");
		XY[] xy = new PathBuilder(new Grid(Main.image)).build();
		Complex[] cs = new Complex[xy.length];
		for (int i = 0; i < xy.length; i++)
			cs[i] = new Complex(xy[i], Main.image.getWidth(), Main.image.getHeight());
		return createFromPath(cs, epicycles);
	}

	public static Chain createFromDots(Complex[] values) {
		Chain result = new Chain(values.length / 2);
		result.pos_coef[0] = result.neg_coef[0] = getCoefficient(values, 0);
		result.pos_abs[0] = result.neg_abs[0] = result.pos_coef[0].abs();
		for (int i = 1; i <= values.length / 2; i++) {
			Complex pos = getCoefficient(values, i), neg = getCoefficient(values, -i);
			result.pos_coef[i] = pos;
			result.pos_abs[i] = pos.abs();
			result.neg_coef[i] = neg;
			result.neg_abs[i] = neg.abs();
			Main.loadingPanel.label.setText("Transforming: " + 200 * i / values.length + "%");
		}
		if (Main.startPanel.saveAdhdCheckbox.isSelected())
			try {
				File file = Main.startPanel.getFile();
				String filename = file.getName();
				if (filename.contains("."))
					filename = filename.substring(0, filename.lastIndexOf('.'));
				result.write(new File(file.getParentFile().getAbsolutePath() + "/" + filename + ".adhd"));
			} catch (IOException e) {
				e.printStackTrace();
			}
		return result;
	}

	public static Chain createFromPath(Complex[] values, int epicycles) {
		return createFromDots(reform(values, epicycles));
	}

	public static Complex[] reform(Complex[] values, int size) {
		Complex[] cs = new Complex[values.length + 1];
		for (int i = 0; i < values.length; i++)
			cs[i] = values[i];
		cs[values.length] = values[0];
		double distSum = 0, dist[] = new double[cs.length - 1];
		for (int i = 0; i < dist.length; i++)
			distSum += dist[i] = cs[i].dist(cs[i + 1]);
		Complex[] result = new Complex[size];
		int i1 = 0;
		double x = 0, dx = distSum / size;
		for (int i = 0; i < size; i++) {
			double fraction = x / dist[i1];
			result[i] = Complex.between(cs[i1], cs[i1 + 1], fraction);
			x += dx;
			while (dist.length != i1 && x > dist[i1])
				x -= dist[i1++];
		}
		return result;
	}

	public static Complex getCoefficient(Complex[] values, int n) {
		Complex result = new Complex();
		for (int i = 0; i < values.length; i++)
			result = result.add(values[i].times(Complex.exp(-2 * Math.PI * n * i / values.length)));
		return result.times(1d / values.length);
	}

	public static Chain read(File file) throws IOException {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		FileInputStream stream = new FileInputStream(file);
		int a;
		byte[] buffer = new byte[256];
		while ((a = stream.read(buffer)) != -1) {
			out.write(buffer, 0, a);
		}
		stream.close();
		ByteArrayInputStream in = new ByteArrayInputStream(out.toByteArray());
		buffer = new byte[4];
		in.read(buffer);
		if (!new String(buffer).equals("ADHD"))
			throw new IOException("Isn't an .ADHD file");
		in.read(buffer);
		Chain result = new Chain(ByteBuffer.wrap(buffer).getInt());
		buffer = new byte[8];
		for (int i = 0; i <= result.r; i++) {
			in.read(buffer);
			double re_pos = ByteBuffer.wrap(buffer).getDouble();
			in.read(buffer);
			double im_pos = ByteBuffer.wrap(buffer).getDouble();
			in.read(buffer);
			double re_neg = ByteBuffer.wrap(buffer).getDouble();
			in.read(buffer);
			double im_neg = ByteBuffer.wrap(buffer).getDouble();
			result.pos_coef[i] = new Complex(re_pos, im_pos);
			result.pos_abs[i] = result.pos_coef[i].abs();
			result.neg_coef[i] = new Complex(re_neg, im_neg);
			result.neg_abs[i] = result.neg_coef[i].abs();
		}
		return result;
	}

	public void write(File file) throws IOException {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		out.write("ADHD".getBytes());
		out.write(ByteBuffer.wrap(new byte[4]).putInt(r).array());
		for (int i = 0; i <= r; i++) {
			out.write(ByteBuffer.wrap(new byte[8]).putDouble(pos_coef[i].re).array());
			out.write(ByteBuffer.wrap(new byte[8]).putDouble(pos_coef[i].im).array());
			out.write(ByteBuffer.wrap(new byte[8]).putDouble(neg_coef[i].re).array());
			out.write(ByteBuffer.wrap(new byte[8]).putDouble(neg_coef[i].im).array());
		}
		FileOutputStream stream = new FileOutputStream(file);
		stream.write(out.toByteArray());
		stream.close();
	}
}
