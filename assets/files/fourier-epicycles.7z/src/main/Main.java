package main;

import java.awt.Font;
import java.awt.image.BufferedImage;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;
import javax.swing.UIManager;

import gui.AnimationPanel;
import gui.DotsPickerPanel;
import gui.DrawingPanel;
import gui.LoadingPanel;
import gui.StartPanel;

public class Main {
	public static Font font = new Font("Myriad Pro", 0, 16);

	public static JFrame frame;
	public static StartPanel startPanel;
	public static DrawingPanel drawingPanel;
	public static DotsPickerPanel dotsPickerPanel;
	public static AnimationPanel animationPanel;
	public static LoadingPanel loadingPanel;
	public static Timer repaintCaller;

	public static int picScale;

	public static BufferedImage image;

	public static void main(String[] args) {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
			e.printStackTrace();
		}
		startPanel = new StartPanel();
		drawingPanel = new DrawingPanel();
		dotsPickerPanel = new DotsPickerPanel();
		animationPanel = new AnimationPanel();
		loadingPanel = new LoadingPanel();
		repaintCaller = new Timer(15, e -> frame.getContentPane().repaint());
		frame = new JFrame("Kurwastudios™ epicycles animations");
		frame.setSize(1600, 900);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(3);
		frame.setContentPane(startPanel);
		frame.setVisible(true);
	}

	public static void setPanel(JPanel panel) {
		frame.setContentPane(panel);
		panel.revalidate();
	}
}
