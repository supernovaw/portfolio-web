package tsp;

public class ForsakenNode {
	public Step[] steps;
	public int index, completed;

	public ForsakenNode(Step[] steps, int index) {
		this.steps = steps;
		this.index = index;
	}

	public boolean equals(Object o) {
		if (o == null)
			return false;
		if (o instanceof ForsakenNode)
			return equals((ForsakenNode) o);
		return false;
	}

	public boolean equals(ForsakenNode node) {
		for (int i = 0; i < node.steps.length; i++) {
			for (int j = 0; j < steps.length; j++)
				for (int k = 0; k < node.steps[i].points.length; k++)
					for (int l = 0; l < steps[j].points.length; l++)
						if (node.steps[i].points[k].equals(steps[j].points[l]))
							return true;
		}
		return false;
	}
}
