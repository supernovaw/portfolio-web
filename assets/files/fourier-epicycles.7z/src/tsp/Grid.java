package tsp;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;

public class Grid {
	public int dots[][], w, h;

	public Grid(File f) throws Exception {
		this(ImageIO.read(f));
	}

	public Grid(BufferedImage img) {
		w = img.getWidth() + 2;
		h = img.getHeight() + 2;
		dots = new int[w][h];
		for (int x = 0; x < w - 2; x++)
			for (int y = 0; y < h - 2; y++)
				dots[x + 1][y + 1] = getValueForColor(img.getRGB(x, y));
	}

	public void markAsVisited(XY[] points) {
		for (XY xy : points)
			dots[xy.x][xy.y] |= 0b10;
	}

	public static int getValueForColor(int c) {
		Color color = new Color(c);
		return color.getRed() + color.getGreen() + color.getBlue() < 100 ? 0b1 : 0b0;
	}
}
