package tsp;

import java.util.ArrayList;

public class Step {
	public XY[] points;

	public Step(XY[] points) {
		this.points = points;
	}

	public Step[] split() {
		boolean[] connected = new boolean[points.length - 1];
		int parts = 1;
		for (int i = 0; i < connected.length; i++) {
			connected[i] = points[i].isClose(points[i + 1]);
			if (!connected[i])
				parts++;
		}
		@SuppressWarnings("unchecked")
		ArrayList<XY>[] stepsList = new ArrayList[parts];
		for (int i = 0; i < parts; i++)
			stepsList[i] = new ArrayList<>();
		stepsList[0].add(points[0]);
		for (int i = 1, j = 0; i < points.length; i++) {
			if (!connected[i - 1])
				j++;
			stepsList[j].add(points[i]);
		}
		Step[] result = new Step[parts];
		for (int i = 0; i < parts; i++)
			result[i] = new Step(stepsList[i].toArray(new XY[stepsList[i].size()]));
		return result;
	}

	public Step moveOn(Grid g) {
		ArrayList<XY> list = new ArrayList<>();
		for (int i = 0; i < points.length; i++) {
			XY[] around = points[i].nearPoints();
			for (int j = 0; j < 8; j++)
				if (g.dots[around[j].x][around[j].y] == 0b1 && !list.contains(around[j]))
					list.add(around[j]);
		}
		return new Step(list.toArray(new XY[list.size()]));
	}

	public String toString() {
		if (points.length == 0)
			return "empty step";
		String s = points[0].toString();
		for (int i = 1; i < points.length; i++)
			s += ",  " + points[i].toString();
		return s;
	}
}
