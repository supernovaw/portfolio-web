package tsp;

public class XY {
	public int x, y;

	public XY(int x, int y) {
		this.x = x;
		this.y = y;
	}

	public XY[] nearPoints() {
		XY[] r = new XY[8];
		r[0] = new XY(x + 1, y - 1);
		r[1] = new XY(x + 1, y + 0);
		r[2] = new XY(x + 1, y + 1);
		r[3] = new XY(x + 0, y + 1);
		r[4] = new XY(x - 1, y + 1);
		r[5] = new XY(x - 1, y + 0);
		r[6] = new XY(x - 1, y - 1);
		r[7] = new XY(x + 0, y - 1);
		return r;
	}

	public boolean isClose(XY xy) {
		int dx = Math.abs(xy.x - x), dy = Math.abs(xy.y - y);
		return Math.max(dx, dy) <= 1;
	}

	public boolean equals(XY xy) {
		return xy.x == x && xy.y == y;
	}

	public boolean equals(Object o) {
		return o instanceof XY ? equals((XY) o) : false;
	}

	public String toString() {
		return x + ";" + y;
	}
}
