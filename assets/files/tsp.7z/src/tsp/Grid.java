package tsp;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;

public class Grid {
	public int dots[][], w, h;

	public Grid(File f) {
		BufferedImage img;
		try {
			img = ImageIO.read(f);
		} catch (Exception e) {
			e.printStackTrace();
			return;
		}
		w = img.getWidth();
		h = img.getHeight();
		dots = new int[w][h];
		for (int x = 0; x < w; x++)
			for (int y = 0; y < h; y++)
				dots[x][y] = getValueForColor(img.getRGB(x, y));
	}

	public void markAsVisited(XY[] points) {
		for (XY xy : points)
			dots[xy.x][xy.y] |= 0b10;
	}

	public static int getValueForColor(int c) {
		Color color = new Color(c);
		return color.getRed() + color.getGreen() + color.getBlue() < 384 ? 0b0 : 0b1;
	}
}
