package tsp;

import java.awt.Color;
import java.awt.Graphics;
import java.io.File;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

public class Main {
	public static void main(String[] args) {
		PathBuilder builder = new PathBuilder(new Grid(new File("C:/Users/Dove/Desktop/path.png")));
		XY[] points = builder.build();
		long start = System.currentTimeMillis();
		int upd = 1;

		JFrame f = new JFrame();
		f.setSize(1024, 720);
		f.setLocationRelativeTo(null);
		f.setDefaultCloseOperation(3);
		f.setContentPane(new JPanel() {
			protected void paintComponent(Graphics g) {
				g.setColor(Color.black);
				g.fillRect(0, 0, getWidth(), getHeight());
				g.setColor(Color.darkGray);
				int sc = 1;
				for (int i = 0; i < points.length - 1; i++)
					g.drawLine(sc * points[i].x, sc * points[i].y, sc * points[i + 1].x, sc * points[i + 1].y);
				g.setColor(Color.white);
				int i = (int) ((System.currentTimeMillis() - start) / upd % (points.length - 1));
				g.drawLine(points[i].x * sc, points[i].y * sc, points[i + 1].x * sc, points[i + 1].y * sc);
			}
		});
		new Timer(upd, e -> f.repaint()).start();
		f.setVisible(true);
	}
}
