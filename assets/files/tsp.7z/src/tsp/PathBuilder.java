package tsp;

import java.util.ArrayList;

public class PathBuilder {
	public Grid grid;

	public PathBuilder(Grid grid) {
		this.grid = grid;
	}

	public XY[] build() {
		ArrayList<XY> route = new ArrayList<>();
		Step current = new Step(new XY[] { findStartingPoint() });
		ArrayList<ForsakenNode> forsaken = new ArrayList<>();
		route.add(current.points[0]);
		while (true) {
			current = current.moveOn(grid);
			grid.markAsVisited(current.points);
			if (current.points.length == 0) {
				if (forsaken.isEmpty()) {
					for (int i = route.indexOf(route.get(route.size() - 1)); i > 0; i--)
						route.add(route.get(i));
					break;
				}
				ForsakenNode last = forsaken.get(forsaken.size() - 1);
				for (int i = route.indexOf(route.get(route.size() - 1)), dest = route.lastIndexOf(route.get(last.index - 1)); i >= dest; i--)
					route.add(route.get(i));
				int completed = ++last.completed;
				if (completed == last.steps.length) {
					forsaken.remove(forsaken.size() - 1);
					continue;
				}
				current = last.steps[completed];
			}
			Step[] split = current.split();
			if (split.length != 1) {
				ForsakenNode node = new ForsakenNode(split, route.size());
				if (!forsaken.contains(node))
					forsaken.add(node);
				current = split[0];
			}
			route.add(current.points[current.points.length / 2]);
		}
		return route.toArray(new XY[route.size()]);
	}

	public XY findStartingPoint() {
		for (int y = 0; y < grid.h; y++)
			for (int x = 0; x < grid.w; x++)
				if ((grid.dots[x][y] & 0b1) != 0)
					return new XY(x, y);
		return null;
	}
}
