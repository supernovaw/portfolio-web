package pack;

import javax.swing.JFrame;

public class Gui extends JFrame {
  static Pane a = new Pane();
  
  private static final long serialVersionUID = -5854938450406459200L;
  
  public Gui() {
    setTitle("Polygon");
    setSize(700, 700);
    setLocationRelativeTo(null);
    setDefaultCloseOperation(3);
    setContentPane(a);
  }
}
