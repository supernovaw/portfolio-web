package pack;

import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.UIManager;

public class Pane extends JPanel {
  int a = 0;
  
  boolean paint = false;
  
  private static final long serialVersionUID = 3775699965209836467L;
  
  public Pane() {
    try {
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    } catch (Exception exception) {}
    addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent arg0) {
            if (arg0.getButton() == 2) {
              Pane.this.repaint();
            } else {
              try {
                Pane.this.a = Integer.parseInt(JOptionPane.showInputDialog("Number of corners"));
                if (Pane.this.a < 1) {
                  Pane.this.paint = false;
                  JOptionPane.showMessageDialog(null, "Wrong count");
                  return;
                } 
                Pane.this.repaint();
              } catch (Exception e) {
                Pane.this.paint = false;
                JOptionPane.showMessageDialog(null, "Wrong count");
                return;
              } 
            } 
            Pane.this.paint = true;
          }
        });
  }
  
  public static Point rt(int gip, int angle, int x, int y) {
    double cos = 1.0D / Math.cos(Math.toRadians(angle));
    double b = gip / cos;
    double c = (gip * gip) - b * b;
    return new Point(x + (int)b, y + (int)((angle < 180) ? Math.sqrt(c) : -Math.sqrt(c)));
  }
  
  protected void paintComponent(Graphics g) {
    if (this.paint) {
      if (this.a != 0) {
        int l = 100, sx = 500, sy = 30, step = 360 / this.a, now = step;
        g.drawLine(sx, sy, sx + l, sy);
        double ox = (sx + l);
        double oy = sy;
        for (int i = 1; i <= this.a; i++) {
          g.drawLine((int)ox, (int)oy, (int)rt(l, now, (int)ox, (int)oy).getX(), 
              (int)rt(l, now, (int)ox, (int)oy).getY());
          Point p = rt(l, now, (int)ox, (int)oy);
          ox = p.x;
          oy = p.y;
          now += step;
        } 
        this.paint = false;
      } 
    } else {
      super.paintComponent(g);
    } 
  }
}
