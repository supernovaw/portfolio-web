package pack;

import javax.swing.JOptionPane;

public class Main {
  public static void main(String[] args) {
    JOptionPane.showMessageDialog(null, 
        "Created by rusZEROj (https://vk.com/ruszrj)                    Создал rusZEROj\n\nTo change location, lenght of lines, go to code.          Чтобы изменить положение и размер измените код.\n\nHas bugs, once will be fixed.)                      Есть баги, будет пофикшено когда нибудь.)");
    (new Gui()).setVisible(true);
  }
}
