package pack;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.geom.AffineTransform;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class Gui extends JFrame {
  static boolean[][] area = new boolean[12][10];
  
  static int h = 16;
  
  static int w = 8;
  
  private static final long serialVersionUID = -2316221095306612943L;
  
  static double scale = 1.0D;
  
  public Gui() {
    setSize(1800, 900);
    setLocationRelativeTo((Component)null);
    setDefaultCloseOperation(1);
    setContentPane(new JPanel() {
          private static final long serialVersionUID = 8516103195340698818L;
          
          protected void paintComponent(Graphics g) {
            int i;
            for (i = 0; i < Gui.area.length; i++) {
              for (int j = 0; j < (Gui.area[i]).length; j++) {
                g.setColor(Gui.area[i][j] ? Color.GREEN : Color.RED);
                g.fillRect(i * Gui.w, j * Gui.h, Gui.w, Gui.h);
              } 
            } 
            g.setColor(Color.BLACK);
            for (i = 0; i < getWidth(); i += Gui.w)
              g.drawLine(i, 0, i, getHeight()); 
            for (i = 0; i < getHeight(); i += Gui.h)
              g.drawLine(0, i, getWidth(), i); 
            if (Main.img) {
              Graphics2D g2 = (Graphics2D)g;
              g2.setComposite(AlphaComposite.getInstance(3, 0.7F));
              AffineTransform at = new AffineTransform();
              at.scale(Gui.scale, Gui.scale);
              g2.drawImage(Main.i, at, null);
            } 
          }
        });
    addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent e) {
            if (e.getButton() == 1) {
              try {
                Gui.area[(e.getX() - 10) / Gui.w][(e.getY() - 31) / Gui.h] = true;
                Gui.this.repaint();
              } catch (Exception exception) {}
            } else if (e.getButton() == 3) {
              try {
                Gui.area[(e.getX() - 10) / Gui.w][(e.getY() - 31) / Gui.h] = false;
                Gui.this.repaint();
              } catch (Exception exception) {}
            } else if (e.getButton() == 2) {
              Gui.area = Gui.this.trim(Gui.area, e.getX() / Gui.w, (e.getY() - 21) / Gui.h);
              Gui.this.repaint();
            } 
          }
        });
    addMouseWheelListener(new MouseWheelListener() {
          public void mouseWheelMoved(MouseWheelEvent e) {
            Gui.scale *= (e.getWheelRotation() == -1) ? 0.9D : 1.1111111111111112D;
            Gui.scale = Math.max(Gui.scale, 0.01D);
            Gui.scale = Math.min(Gui.scale, 500.0D);
            Gui.this.repaint();
          }
        });
    addMouseMotionListener(new MouseMotionListener() {
          public void mouseMoved(MouseEvent arg0) {}
          
          public void mouseDragged(MouseEvent e) {
            if (SwingUtilities.isMiddleMouseButton(e)) {
              Gui.area = Gui.this.trim(Gui.area, e.getX() / Gui.w, (e.getY() - 21) / Gui.h);
              Gui.this.repaint();
            } else {
              try {
                Gui.area[(e.getX() - 10) / Gui.w][(e.getY() - 31) / Gui.h] = 
                  SwingUtilities.isLeftMouseButton(e);
                Gui.this.repaint();
              } catch (Exception exception) {}
            } 
          }
        });
    setFocusable(true);
    addKeyListener(new KeyAdapter() {
          public void keyTyped(KeyEvent e) {
            char[][] im = new char[Gui.area.length][(Gui.area[0]).length];
            for (int i = 0; i < im.length; i++) {
              for (int n = 0; n < (im[i]).length; n++)
                im[i][n] = Gui.area[i][n] ? ': '; 
            } 
            String[] strings = new String[(im[0]).length];
            int k;
            for (k = 0; k < strings.length; k++)
              strings[k] = ""; 
            for (k = 0; k < im.length; k++) {
              for (int n = 0; n < (im[k]).length; n++) {
                int tmp118_116 = n;
                String[] tmp118_115 = strings;
                tmp118_115[tmp118_116] = String.valueOf(tmp118_115[tmp118_116]) + im[k][n];
              } 
            } 
            String string = "";
            String[] arrayOfString1;
            int j = (arrayOfString1 = strings).length;
            for (int m = 0; m < j; m++) {
              String arg = arrayOfString1[m];
              string = String.valueOf(string) + arg + "\n";
            } 
            while (string.endsWith("\n"))
              string = string.substring(0, string.length() - 1); 
            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new StringSelection(string), 
                new StringSelection(string));
          }
        });
    setDefaultCloseOperation(3);
  }
  
  public boolean[][] trim(boolean[][] arg0, int l1, int l2) {
    l1 = Math.max(1, l1);
    l2 = Math.max(1, l2);
    boolean[][] n = new boolean[l1][l2];
    for (int i = 0; i < n.length; i++) {
      for (int j = 0; j < (n[i]).length; j++) {
        boolean a = false;
        if (arg0.length > i && (arg0[i]).length > j)
          a = arg0[i][j]; 
        n[i][j] = a;
      } 
    } 
    return n;
  }
}
