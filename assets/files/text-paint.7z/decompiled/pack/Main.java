package pack;

import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;
import javax.swing.JOptionPane;
import javax.swing.UIManager;

public class Main {
  static boolean img = false;
  
  static BufferedImage i = null;
  
  public static void main(String[] args) {
    try {
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    } catch (Exception exception) {}
    String path = JOptionPane.showInputDialog("Select path to background image or leave empty");
    if (path != null)
      try {
        i = ImageIO.read(new File(path));
        img = true;
      } catch (Exception e) {
        img = false;
      }  
    JOptionPane.showMessageDialog(null, 
        "Left click = Draw with green\nMiddle click = Set size\nRight click = Draw with red\nPress any key = Copy image to clipdoard (as text)");
    (new Gui()).setVisible(true);
  }
}
