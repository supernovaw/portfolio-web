package com.example.androidapptest

import android.content.Context
import android.content.pm.ActivityInfo
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.SensorManager.SENSOR_DELAY_FASTEST
import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*
import java.io.PrintStream
import java.net.Socket
import java.util.*
import kotlin.collections.ArrayList

class MainActivity : AppCompatActivity(), SensorEventListener {
	private var connection: Socket? = null
	private var connectionThread: Thread? = null
	private val sendQueue = ArrayList<String>()

	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(R.layout.activity_main)
		requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT

		connect_button.setOnClickListener { startStuff() }

		val sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
		val sensor = sensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION)
		sensorManager.registerListener(this, sensor, SENSOR_DELAY_FASTEST)

		calibrate.setOnClickListener {
			sendQueue.add("/calibrate")
		}
	}

	override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
		sendQueue.add("/calibrate")
		return true
	}

	override fun onSensorChanged(event: SensorEvent?) {
		if (connection == null || event?.values == null) return
		sendQueue += Arrays.toString(event.values)
	}

	override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

	private fun startStuff() {
		connection?.close()
		connectionThread?.interrupt()
		connectionThread = Thread {
			try {
				connection = Socket(ip_input.text.toString(), 42069)
				val connectionStream = PrintStream(connection?.getOutputStream())
				while (true) {
					Thread.sleep(10)
					while (!sendQueue.isEmpty()) {
						connectionStream.println(sendQueue.removeAt(0))
					}
				}
			} catch (e: Exception) {
				Log.v("MainActivity", "Error", e)
			}
		}.also(Thread::start)
	}
}