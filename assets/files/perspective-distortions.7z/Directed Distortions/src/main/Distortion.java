package main;

import java.awt.*;
import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

// X - L/R; Y - D/U; Z - B/F
public class Distortion {
	private static final double picW = 0.19, picH = 0.1, distance = 0.5;
	private static final XYZ screenTL = new XYZ(-picW / 2d, picH / 2d, 0);
	private static final XYZ screenTR = new XYZ(picW / 2d, picH / 2d, 0);
	private static final XYZ screenBR = new XYZ(picW / 2d, -picH / 2d, 0);
	private static final XYZ screenBL = new XYZ(-picW / 2d, -picH / 2d, 0);

	public static Polygon magic(double[] angles, double[] calibration, int pxW, int pxH) {
		XYZ viewer = new XYZ(0, 0, -distance);
		Rotation orig = new Rotation(Math.toRadians(angles[0]),
				Math.toRadians(angles[1] + 90), Math.toRadians(angles[2]));
		Rotation cal = calibration(calibration);
		viewer.rotate(orig);
		viewer.rotateRev(cal);

		List<XYZ> list = new ArrayList<>(4);
		list.add(screenTL.copy());
		list.add(screenTR.copy());
		list.add(screenBR.copy());
		list.add(screenBL.copy());

		list.forEach(p -> p.rotate(orig));
		list.forEach(p -> p.rotateRev(cal));
		list.forEach(p -> p.subtract(viewer));
		list.forEach(p -> p.projectToZ(-viewer.z));
		list.forEach(p -> p.add(viewer));

		int cx = pxW / 2, cy = pxH / 2;
		// rs - relative screen
		XYZ rsTL = list.get(0);
		XYZ rsTR = list.get(1);
		XYZ rsBR = list.get(2);
		XYZ rsBL = list.get(3);
		int[] xs = {cx + (int) (rsTL.x * pxW), cx + (int) (rsTR.x * pxW),
				cx + (int) (rsBR.x * pxW), cx + (int) (rsBL.x * pxW)};
		int[] ys = {cy - (int) (rsTL.y * pxW), cy - (int) (rsTR.y * pxW),
				cy - (int) (rsBR.y * pxW), cy - (int) (rsBL.y * pxW)};
		return new Polygon(xs, ys, 4);
	}

	private static Rotation calibration(double[] calibration) {
		XYZ p = new XYZ(0, 0, 1);
		p.rotate(new Rotation(Math.toRadians(calibration[0]),
				Math.toRadians(calibration[1]), Math.toRadians(calibration[2])));
		double revYaw = Math.atan2(p.x, p.z);
		p.rotate(new Rotation(-revYaw, 0, 0));
		double revPitch = -Math.atan2(p.y, p.z);
		return new Rotation(-revYaw, -revPitch, 0);
	}

	public static void paint(BufferedImage img, Graphics2D g, Polygon p) {
		int ptsX = img.getWidth() + 1, ptsY = img.getHeight() + 1;
		Point2D tl = new Point2D.Double(p.xpoints[0], p.ypoints[0]);
		Point2D tr = new Point2D.Double(p.xpoints[1], p.ypoints[1]);
		Point2D br = new Point2D.Double(p.xpoints[2], p.ypoints[2]);
		Point2D bl = new Point2D.Double(p.xpoints[3], p.ypoints[3]);
		Point2D intersectionHoriz = Intersections.intersection(tl, tr, bl, br);
		Point2D intersectionVert = Intersections.intersection(tl, bl, tr, br);
		Point2D[][] matrix = new Point2D[ptsX][ptsY];
		matrix[0][0] = tl;
		matrix[ptsX - 1][0] = tr;
		matrix[ptsX - 1][ptsY - 1] = br;
		matrix[0][ptsY - 1] = bl;
		for (int y = 1; y < ptsY - 1; y++) {
			double f = y / (ptsY - 1d);
			matrix[0][y] = interp(tl, bl, intersectionVert, f);
			matrix[ptsX - 1][y] = interp(tr, br, intersectionVert, f);
		}
		for (int y = 0; y < ptsY; y++) {
			Point2D left = matrix[0][y], right = matrix[ptsX - 1][y];
			for (int x = 1; x < ptsX - 1; x++) {
				matrix[x][y] = interp(left, right, intersectionHoriz, x / (ptsX - 1d));
			}
		}
		for (int y = 0; y < img.getHeight(); y++) {
			for (int x = 0; x < img.getWidth(); x++) {
				int color = img.getRGB(x, y);
				Point2D[] ps = {matrix[x][y], matrix[x + 1][y], matrix[x + 1][y + 1], matrix[x][y + 1]};
				int[] xs = {(int) ps[0].getX(), (int) ps[1].getX(), (int) ps[2].getX(), (int) ps[3].getX()};
				int[] ys = {(int) ps[0].getY(), (int) ps[1].getY(), (int) ps[2].getY(), (int) ps[3].getY()};
				g.setColor(new Color(color));
				g.fillPolygon(xs, ys, 4);
			}
		}
	}

	private static Point2D interp(Point2D p1, Point2D p2, Point2D perspective, double f) {
		double perspectiveF;
		if (Math.abs(p2.getX() - p1.getX()) > Math.abs(p2.getY() - p1.getY()))
			perspectiveF = perspectiveInterpolationF(p1.getX(), p2.getX(), perspective.getX(), f);
		else
			perspectiveF = perspectiveInterpolationF(p1.getY(), p2.getY(), perspective.getY(), f);
		return new Point2D.Double(p1.getX() + (p2.getX() - p1.getX()) * perspectiveF,
				p1.getY() + (p2.getY() - p1.getY()) * perspectiveF);
	}

	private static double perspectiveInterpolationF(double p1, double p2, double perspective, double sourceF) {
		if (!Double.isFinite(perspective)) return sourceF;
		p1 -= perspective;
		p2 -= perspective;
		double offset = p1 / (p2 - p1);
		return offset * (offset + 1) / (offset - sourceF + 1) - offset;
	}
}
