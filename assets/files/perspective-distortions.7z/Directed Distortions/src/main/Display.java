package main;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;

public class Display {
	private static double[] displayedData, calibrated = new double[3];
	private static JPanel content;
	private static BufferedImage image;

	public static void init() {
		try {
			image = ImageIO.read(new File("/Users/supernovaw/Desktop/us320.png"));
		} catch (Exception e) {
			throw new Error(e);
		}

		JFrame frame = new JFrame();
		frame.setSize(1500, 800);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		frame.setContentPane(content = new JPanel() {
			protected void paintComponent(Graphics g) {
				Graphics2D g2d = (Graphics2D) g;
				g2d.setColor(Color.black);
				g2d.fillRect(0, 0, getWidth(), getHeight());
//				g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
				if (displayedData != null && displayedData.length > 0) {
					Polygon poly = Distortion.magic(displayedData, calibrated, getWidth(), getHeight());
					Distortion.paint(image, g2d, poly);
//					g2d.setColor(Color.white);
//					g2d.drawPolygon(poly);
				}
			}
		});
		frame.setVisible(true);
	}

	public static void updateData(double[] data) {
		displayedData = data;
		content.repaint();
	}

	public static void calibrate() {
		calibrated = displayedData;
	}
}
