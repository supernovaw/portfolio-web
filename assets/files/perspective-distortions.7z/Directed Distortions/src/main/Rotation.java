package main;

public class Rotation {
	public double yaw, pitch, roll;
	public double ys, yc, ps, pc, rs, rc;

	public Rotation(double yaw, double pitch, double roll) {
		this.yaw = yaw;
		this.pitch = pitch;
		this.roll = roll;
		ys = Math.sin(yaw);
		yc = Math.cos(yaw);
		ps = Math.sin(pitch);
		pc = Math.cos(pitch);
		rs = Math.sin(roll);
		rc = Math.cos(roll);
	}
}
