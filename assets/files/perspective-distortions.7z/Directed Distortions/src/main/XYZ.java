package main;

public class XYZ {
	public double x, y, z;

	public XYZ(double x, double y, double z) {
		this.x = x;
		this.y = y;
		this.z = z;
	}

	public void rotateY(double ang) {
		double cos = Math.cos(ang);
		double sin = Math.sin(ang);
		double nX = x * cos + z * sin;
		double nZ = z * cos - x * sin;
		x = nX;
		z = nZ;
	}

	public void rotateX(double ang) {
		double cos = Math.cos(ang);
		double sin = Math.sin(ang);
		double nY = y * cos + z * sin;
		double nZ = z * cos - y * sin;
		y = nY;
		z = nZ;
	}

	public void rotate(Rotation r) {
		double t1, t2;
		t1 = y * r.pc - z * r.ps; // pitch
		t2 = z * r.pc + y * r.ps;
		y = t1;
		z = t2;
		t1 = x * r.rc + y * r.rs; // roll
		t2 = y * r.rc - x * r.rs;
		x = t1;
		y = t2;
		t1 = x * r.yc + z * r.ys; // yaw
		t2 = z * r.yc - x * r.ys;
		x = t1;
		z = t2;
	}

	public void rotateRev(Rotation r) {
		double t1, t2;
		t1 = x * r.yc + z * r.ys; // yaw
		t2 = z * r.yc - x * r.ys;
		x = t1;
		z = t2;

		t1 = x * r.rc + y * r.rs; // roll
		t2 = y * r.rc - x * r.rs;
		x = t1;
		y = t2;

		t1 = y * r.pc - z * r.ps; // pitch
		t2 = z * r.pc + y * r.ps;
		y = t1;
		z = t2;
	}

	public void subtract(XYZ xyz) {
		x -= xyz.x;
		y -= xyz.y;
		z -= xyz.z;
	}

	public void add(XYZ xyz) {
		x += xyz.x;
		y += xyz.y;
		z += xyz.z;
	}

	public void projectToZ(double toZ) {
		x *= toZ / z;
		y *= toZ / z;
		z = toZ;
	}

	public XYZ copy() {
		return new XYZ(x, y, z);
	}
}
