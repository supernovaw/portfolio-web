package main;

import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class Connection {
	private static Thread serverThread;
	private static ServerSocket server;
	private static Socket currentConnection;
	private static Scanner currentInput;

	public static void init() {
		serverThread = new Thread(() -> {
			try {
				server = new ServerSocket(42069);
				while (true) {
					System.out.println("Waiting for an incoming connection");
					currentConnection = server.accept();
					System.out.println("Accepted " + currentConnection.getInetAddress());
					currentInput = new Scanner(currentConnection.getInputStream());
					while (currentInput.hasNext()) onInput(currentInput.nextLine());
					System.out.println(currentConnection.getInetAddress() + ":"
							+ currentConnection.getLocalPort() + " disconnected");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
		serverThread.start();
	}

	public static void shutdown() {
		serverThread.interrupt();
		try {
			server.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static void onInput(String input) {
		if (input == null || input.equals("null")) return;
		if (input.equals("/calibrate")) {
			Display.calibrate();
			return;
		}
		try {
			String[] split = input.substring(1, input.length() - 1).split(", ");
			double[] data = new double[split.length];
			for (int i = 0; i < split.length; i++) data[i] = Double.parseDouble(split[i]);

			data[2] *= -1;
			Display.updateData(data);
		} catch (Exception e) {
			System.out.println("Invalid input " + input + " (" + e.getClass().getSimpleName() + ")");
		}
	}
}
