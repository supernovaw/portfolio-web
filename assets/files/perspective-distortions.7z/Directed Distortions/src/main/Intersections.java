package main;

import java.awt.geom.Point2D;

public class Intersections {
	private static final double Q = 0.414;
	private static final int[][] TRANSFORMATION_TABLE = {
			{0, 0, 0, 2, 2, 0, 0, 0},
			{0, 0, 0, 1, 2, 0, 0, 0},
			{0, 0, 1, 1, 2, 1, 0, 0},
			{2, 1, 1, 1, 1, 3, 3, 2},
			{2, 2, 2, 1, 1, 1, 1, 2},
			{0, 0, 1, 3, 1, 1, 0, 0},
			{0, 0, 0, 3, 1, 0, 0, 0},
			{0, 0, 0, 2, 2, 0, 0, 0}
	};
	private static final Transformation[] TRANSFORMATIONS = {new Transformation.None(),
			new Transformation.Swap(), new Transformation.CW(), new Transformation.CCW()};

	public static Point2D intersection(double l1p1x, double l1p1y, double l1p2x, double l1p2y,
									   double l2p1x, double l2p1y, double l2p2x, double l2p2y) {
		int ss1 = lineSlopeSector(l1p1x, l1p1y, l1p2x, l1p2y);
		int ss2 = lineSlopeSector(l2p1x, l2p1y, l2p2x, l2p2y);
		Transformation t = TRANSFORMATIONS[TRANSFORMATION_TABLE[ss1][ss2]];
		Point2D l1p1t = t.convert(l1p1x, l1p1y);
		Point2D l1p2t = t.convert(l1p2x, l1p2y);
		Point2D l2p1t = t.convert(l2p1x, l2p1y);
		Point2D l2p2t = t.convert(l2p2x, l2p2y);
		Point2D resultTransformed = intersectionEquation(l1p1t, l1p2t, l2p1t, l2p2t);
		return t.convertBack(resultTransformed.getX(), resultTransformed.getY());
	}

	public static Point2D intersection(Point2D l1p1, Point2D l1p2, Point2D l2p1, Point2D l2p2) {
		return intersection(l1p1.getX(), l1p1.getY(), l1p2.getX(), l1p2.getY(),
				l2p1.getX(), l2p1.getY(), l2p2.getX(), l2p2.getY());
	}

	private static int lineSlopeSector(double p1x, double p1y, double p2x, double p2y) {
		double dx = p2x - p1x, dy = p2y - p1y;
		double tan = dy / dx;
		if (tan < -1 / Q) return 4;
		if (tan < -1) return 5;
		if (tan < -Q) return 6;
		if (tan < 0) return 7;
		if (tan < Q) return 0;
		if (tan < 1) return 1;
		if (tan < 1 / Q) return 2;
		return 3;
	}

	private static Point2D intersectionEquation(Point2D l1p1, Point2D l1p2, Point2D l2p1, Point2D l2p2) {
		double t1 = (l1p2.getY() - l1p1.getY()) / (l1p2.getX() - l1p1.getX());
		double t2 = (l2p2.getY() - l2p1.getY()) / (l2p2.getX() - l2p1.getX());
		double h1 = l1p1.getY() - t1 * l1p1.getX();
		double h2 = l2p1.getY() - t2 * l2p1.getX();
		double x = (h2 - h1) / (t1 - t2);
		return new Point2D.Double(x, x * t1 + h1);
	}

	private interface Transformation {
		Point2D convert(double x, double y);

		Point2D convertBack(double x, double y);

		class None implements Transformation {
			public Point2D convert(double x, double y) {
				return new Point2D.Double(x, y);
			}

			public Point2D convertBack(double x, double y) {
				return new Point2D.Double(x, y);
			}
		}

		class Swap implements Transformation {
			public Point2D convert(double x, double y) {
				return new Point2D.Double(y, x);
			}

			public Point2D convertBack(double x, double y) {
				return new Point2D.Double(y, x);
			}
		}

		class CCW implements Transformation {
			public Point2D convert(double x, double y) {
				return new Point2D.Double(x - y, y + x);
			}

			public Point2D convertBack(double x, double y) {
				return new Point2D.Double((x + y) / 2d, (y - x) / 2d);
			}
		}

		class CW implements Transformation {
			public Point2D convert(double x, double y) {
				return new Point2D.Double(x + y, y - x);
			}

			public Point2D convertBack(double x, double y) {
				return new Point2D.Double((x - y) / 2d, (y + x) / 2d);
			}
		}
	}
}
