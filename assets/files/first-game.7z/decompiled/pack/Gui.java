package pack;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Timer;

public class Gui extends JFrame {
  static ArrayList<Mob> mobs = new ArrayList<>();
  
  static ArrayList<Bullet> bullets = new ArrayList<>();
  
  static Gun gun = new Gun();
  
  static int delay = 10;
  
  static boolean holda;
  
  static boolean holdd;
  
  static boolean holdspace;
  
  private static final long serialVersionUID = -5854938450406459200L;
  
  public Gui() {
    setResizable(false);
    setSize(1000, 700);
    setLocationRelativeTo((Component)null);
    setDefaultCloseOperation(3);
    setFocusable(true);
    mobs.add(new Mob());
    try {
      setIconImage(ImageIO.read(getClass().getResourceAsStream("/res/icon.jpg")));
      Mob.mob0 = ImageIO.read(getClass().getResourceAsStream("/res/mob0.jpg"));
      Mob.mob1 = ImageIO.read(getClass().getResourceAsStream("/res/mob1.jpg"));
      Mob.mob2 = ImageIO.read(getClass().getResourceAsStream("/res/mob2.jpg"));
      Mob.mob3 = ImageIO.read(getClass().getResourceAsStream("/res/mob3.jpg"));
      Mob.mob4 = ImageIO.read(getClass().getResourceAsStream("/res/mob4.jpg"));
      Mob.mob5 = ImageIO.read(getClass().getResourceAsStream("/res/mob5.jpg"));
      Bullet.bullet = ImageIO.read(getClass().getResourceAsStream("/res/bullet.jpg"));
      Gun.gun = ImageIO.read(getClass().getResourceAsStream("/res/gun.jpg"));
    } catch (IOException e) {
      e.printStackTrace();
    } 
    setTitle("Game");
    setContentPane(new JPanel() {
          private static final long serialVersionUID = -175784246912101181L;
          
          protected void paintComponent(Graphics g) {
            g.setColor(Color.black);
            g.fillRect(0, 0, getWidth(), getHeight());
            paintMobs(g);
            paintBullets(g);
            paintGun(g);
          }
          
          protected void paintMobs(Graphics g) {
            for (Mob arg : Gui.mobs)
              g.drawImage(arg.draw(), arg.x, arg.y, null); 
          }
          
          protected void paintBullets(Graphics g) {
            for (Bullet arg : Gui.bullets)
              g.drawImage(arg.draw(), arg.x, getHeight() - arg.y, null); 
          }
          
          protected void paintGun(Graphics g) {
            g.drawImage(Gun.gun, Gui.gun.x, getHeight() - Gun.gun.getHeight() + Gui.gun.cd / 10, null);
          }
        });
    (new Timer(delay, ActionListener -> {
          for (Mob arg : mobs) {
            if (arg.x + 160 > getWidth() && arg.right) {
              arg.y += 80;
              arg.right = false;
            } else if (arg.x - 80 < 0 && !arg.right) {
              arg.y += 80;
              arg.right = true;
            } else {
              arg.x += arg.right ? 1 : -1;
            } 
            if (arg.y + 80 > getHeight()) {
              JOptionPane.showMessageDialog(null, "You lose.");
              System.exit(0);
            } 
          } 
          int i;
          for (i = 0; i < mobs.size(); i++) {
            if (((Mob)mobs.get(i)).hp <= 0)
              mobs.remove(i); 
          } 
          for (i = 0; i < bullets.size(); i++) {
            if (((Bullet)bullets.get(i)).y >= getHeight()) {
              bullets.remove(i);
            } else if (((Bullet)bullets.get(i)).hp <= 0) {
              bullets.remove(i);
            } 
          } 
          repaint();
        })).start();
    (new Timer(delay * 300, ActionListener -> {
        
        })).start();
    addKeyListener(new KeyAdapter() {
          public void keyPressed(KeyEvent e) {
            if (e.getKeyCode() == 65)
              Gui.holda = true; 
            if (e.getKeyCode() == 68)
              Gui.holdd = true; 
            if (e.getKeyCode() == 32)
              Gui.holdspace = true; 
          }
          
          public void keyReleased(KeyEvent e) {
            if (e.getKeyCode() == 65)
              Gui.holda = false; 
            if (e.getKeyCode() == 68)
              Gui.holdd = false; 
            if (e.getKeyCode() == 32)
              Gui.holdspace = false; 
          }
        });
    (new Timer(delay / 2, ActionListener -> {
          if (holda && gun.x > 0)
            gun.x -= 20; 
          if (holdd && gun.x + 3 * Gun.gun.getWidth() < getWidth())
            gun.x += 20; 
          if (holdspace && gun.cd == 0) {
            gun.shoot();
            bullets.add(new Bullet(gun.x + 3));
          } 
          if (gun.cd > 0)
            gun.cd--; 
          for (Bullet arg : bullets)
            arg.y += 10; 
        })).start();
    (new Timer(10, ActionListener -> {
          for (Mob arg : mobs) {
            for (Bullet arg0 : bullets) {
              if ((new Rectangle(arg.x, arg.y, Mob.s, Mob.s)).contains(arg0.x, getHeight() - arg0.y)) {
                arg.hp -= 4;
                arg0.hp -= 8;
              } 
            } 
          } 
        })).start();
  }
}
