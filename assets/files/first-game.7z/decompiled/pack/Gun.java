package pack;

import java.awt.image.BufferedImage;

public class Gun {
  static BufferedImage gun = null;
  
  int x = 100, cd = 0;
  
  public void shoot() {
    this.cd = 30;
  }
}
