package pack;

import javax.swing.JOptionPane;
import javax.swing.UIManager;

public class Main {
  public static void main(String[] args) {
    try {
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    } catch (Exception exception) {}
    JOptionPane.showMessageDialog(null, "Use A, D, and Space to move and shoot.\nProtect gun keeping at distance the aliens.");
    (new Gui()).setVisible(true);
  }
}
