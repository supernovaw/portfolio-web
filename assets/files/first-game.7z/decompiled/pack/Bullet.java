package pack;

import java.awt.image.BufferedImage;

public class Bullet {
  static BufferedImage bullet = null;
  
  int x;
  
  int y;
  
  int hp = 100;
  
  public Bullet(int x) {
    this.x = x;
  }
  
  public BufferedImage draw() {
    return bullet;
  }
}
