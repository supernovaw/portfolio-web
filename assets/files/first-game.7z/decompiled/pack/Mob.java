package pack;

import java.awt.image.BufferedImage;

public class Mob {
  public static BufferedImage mob5 = null;
  
  public static BufferedImage mob4 = null;
  
  public static BufferedImage mob3 = null;
  
  public static BufferedImage mob2 = null;
  
  public static BufferedImage mob1 = null;
  
  public static BufferedImage mob0 = null;
  
  int x = 10;
  
  int y = 10;
  
  int hp = 100;
  
  boolean right = true;
  
  static int s = 70;
  
  public BufferedImage draw() {
    if (this.hp == 100)
      return mob5; 
    if (this.hp > 80)
      return mob4; 
    if (this.hp > 60)
      return mob3; 
    if (this.hp > 40)
      return mob2; 
    if (this.hp > 20)
      return mob1; 
    return mob0;
  }
}
